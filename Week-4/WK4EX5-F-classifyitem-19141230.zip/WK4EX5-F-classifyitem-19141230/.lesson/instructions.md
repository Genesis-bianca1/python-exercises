## Instructions

Write a function `classify_item` whose parameters are the weight, length, width, and depth of an item to be sent to the USA (in that order, with weight in g and dimensions in **cm**)and which **calls** the functions `is_small_parcel` and `is_letter` developed in earlier exercises and then returns an integer value in the range 0-2 whose meaning is

0: The item cannot be sent to the USA as a letter or a small parcel

1: The item can be sent as a letter

2: The item can be sent as a small parcel, but **not** as a letter.

Note: you can cut and paste the the functions `is_small_parcel` and `is_letter` developed in the previous exercises.

**N.B** The arguments passed to `is_letter` are expressed in mm. The arguments of `classify_item` are in cm,  so you will need to multiply by 10 before passing them to `is_letter`.

**N.B.** The function `classify_item` should **call** the functions `is_small_parcel` and `is_letter`. You should not simply include the code for those functions into `classify_item`. Both `is_small_parcel` and `is_letter` will be tested in this project, so you should simply paste in the previously developed versions, without than changing them.

## Example of use (in Python console)
```
> res = classify_item(101,24,16.5,0.5)
> print(res)
2
> res = classify_item(100,24,16.5,0.5)
> print(res)
1
> res = classify_item(2001,24,16.5,0.5)
> print(res)
0
```
## Explanation of automated tests

The project has automated tests for all three functions `classify_item`, `is_small_parcel`, and `is_letter`. The functions called, arguments passed, and expected return values are as follows. Note that the length, width, and depth arguments are expressed in mm when passed to `is_letter` and in cm when passed to the other two functions.


| Test| function | Arguments (weight, length, width, depth)| Expected return value | 
| --- | ---  | --- | --- |
| test_1 | is_letter | 100,240,165,5| True | 
| test_2 | is_small_parcel | 2000,60,20,10| True | 
| test_3 | classify_item` | 101,24,16.4,0.4| 2 | 
| test_4 | classify_item` | 100,24,16.4,0.4 | 1 | 
| test_5 | classify_item` | 100,24,71,0.4| 0 | 

