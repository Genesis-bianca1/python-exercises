#IMPORTANT: DO NOT CHANGE THIS FILE!
from main import is_letter, is_small_parcel, classify_item

def test1(testCase):
  doTest(testCase,is_letter,"is_letter",(bool),100,240,165,5,True)

def test2(testCase):
  doTest(testCase,is_small_parcel,"is_small_parcel",(bool),2000,60,20,10,True)

def test3(testCase):
  doClassifyTest(testCase,101,24,16.4,0.4,2)

def test4(testCase):
  doClassifyTest(testCase,100,24,16.4,0.4,1)

def test5(testCase):
  doClassifyTest(testCase,100,24,71,0.4,0)

def doClassifyTest(testCase,weight,length,width,depth,expected):
  doTest(testCase,classify_item,"classify_item",(int,float),weight,length,width,depth,expected)

def doTest(testCase,functor,functorName,types,weight,length,width,depth,expected):
  actual = functor(weight,length,width,depth)
  if not isinstance(actual,types):
    explanation = "Return value is not of correct type"
    msg = makeMessage(functorName,weight,length,width,depth, expected,actual,explanation)
    testCase.fail(msg)
  if expected != actual:
    msg = makeMessage(functorName,weight,length,width,depth, expected,actual,"Actual and expected return values are not equal")
    testCase.fail(msg)


def makeMessage(functorName,weight,length,width,depth, expected,actual,explanation):
  bar ="\n##################################\n"
  msg = bar + "Function call: " + callToStr(functorName, weight,length,width,depth) 
  msg += "\nExpected return value: " + repr(expected)
  msg += "\nActual return value: " + repr(actual)
  msg += "\n" + explanation + bar
  return msg

def callToStr(functor,*args):
  call = functor + "("
  nbrArgs = len(args)
  for i in range(0,nbrArgs):
    call += repr(args[i])
    if i == nbrArgs-1:
      call += ")"
    else:
      call += ","
  return call