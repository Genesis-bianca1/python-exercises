## Instructions
This project is not an exercise. It is an area in which you can write experimental code related to this week's material.