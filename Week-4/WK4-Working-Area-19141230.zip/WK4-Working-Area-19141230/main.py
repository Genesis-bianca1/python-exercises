def count_odds(numlist):
  #Returns the odd numbers in numlist
    while n < len(split_list):
      n = int(input("Enter a list of values separated by comma: "))
      split_list = n.split(",")
      odds_list = split_list%2==0
    print(odds_list)
    return odds_list
