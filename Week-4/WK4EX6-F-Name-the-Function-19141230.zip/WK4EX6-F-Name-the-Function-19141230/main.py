# I replaced 'xxx' with 'even_nums' because the function returns 'True' for multiples of 2, and 'False' for 'odd' numbers (not divisible by 2).
def even_nums(n):
  return n % 2 == 0