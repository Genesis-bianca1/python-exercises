## Instructions

**Note:** There are no automated tests for this exercise.

What does the function `xxx` in the file main.py do? Can you suggest a better name for it than `xxx`?