#IMPORTANT: DO NOT CHANGE THIS FILE!
from main import is_small_parcel

def test1(testCase):
  doTest(testCase, 2000,60,20,10,True)
def test2(testCase):
  doTest(testCase, 2000,20,60,10,True)
def test3(testCase):
  doTest(testCase, 2000,20,10,60,True)
def test4(testCase):
  doTest(testCase, 2001,60,20,10,False)
def test5(testCase):
  doTest(testCase, 2000,60,21,10,False)
def test6(testCase):
  doTest(testCase, 2000,61,10,19,False)
def test7(testCase):
  doTest(testCase, 2000,10,61,19,False)
def test8(testCase):
  doTest(testCase, 2000,10,19,61,False)


def doTest(testCase,weight,length,width,depth,expected):
  actual = is_small_parcel(weight,length,width,depth)
  if not isinstance(actual,bool):
    explanation = "Return value is not Boolean"
    msg = makeMessage(weight,length,width,depth, expected,actual,explanation)
    testCase.fail(msg)
  if expected != actual:
    msg = makeMessage(weight,length,width,depth, expected,actual,"Actual and expected return values are not equal")
    testCase.fail(msg)


def makeMessage(weight,length,width,depth, expected,actual,explanation):
  bar ="\n##################################\n"
  msg = bar + "Function call: " + callToStr("is_small_parcel", weight,length,width,depth) 
  msg += "\nExpected return value: " + repr(expected)
  msg += "\nActual return value: " + repr(actual)
  msg += "\n" + explanation + bar
  return msg

def callToStr(functor,*args):
  call = functor + "("
  nbrArgs = len(args)
  for i in range(0,nbrArgs):
    call += repr(args[i])
    if i == nbrArgs-1:
      call += ")"
    else:
      call += ","
  return call