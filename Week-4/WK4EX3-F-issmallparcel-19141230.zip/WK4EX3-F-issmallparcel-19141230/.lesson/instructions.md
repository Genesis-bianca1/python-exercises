## Instructions
If you want to send an item to the US by Royal Mail as a &quot;Small Parcel&quot; it must meet the following criteria (which you can find at https://www.royalmail.com/price-finder):

- The weight must be no more than 2000g.
- The sum of the three dimensions (length + width + depth) must be no more than 90cm.
- No individual dimension can be greater than 60cm.

Write a **function** `is_small_parcel` that takes the weight, length, width, and depth of an item as parameters (in that order) and **returns** `True` if the parcel can be sent as a Small Parcel and `False` otherwise. The weight should be expressed in g and the other dimensions in cm.

## Example of use (in Python console)
```
> check = is_small_parcel(2000,60,20,10)
> print(check)
True
```

## Explanation of automated tests

The arguments passed to the function during the tests, and the expected return values are shown below

| Test| arguments(weight, length, width, depth)| Expected return value | 
| --- | ---  | --- |
| test_1 | 2000,60,20,10| True | 
| test_2 | 2000,20,60,10| True |
| test_3 | 2000,20,10,60| True |
| test_4 | 2001,60,20,10| False|
| test_5 | 2000,60,21,10| False|
| test_6 | 2000,61,10,19| False|
| test_7 | 2000,10,61,19| False|
| test_8 | 2000,10,19,61| False|
