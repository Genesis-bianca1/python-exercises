## Instructions

Write a function `count_odds` such that, if `numlist` is a list of integers, then `count_odds(numlist)` returns the number of odd values in that list.

Example of use (in a Python console)
```
>n = count_odds([1,3,2,6,9,8,7])
>print(n)
4
```
## Explanation of automated tests

The arguments passed to the function during the tests, and the expected return values are shown below.

| Test| argument| Expected return value | 
| --- | ---  | --- |
| test_1 | [1,5,2,4,9,8,7] | 4 | 
| test_2 | [2,6,4,20,10,4,8] | 0 |
| test_3 | [] | 0|
