from main import count_odds

def test1(testcase):
  inlist = [1,5,2,4,9,8,7]
  dotest(testcase,inlist,4)

def test2(testcase):
  inlist = [2,6,4,20,10,4,8]
  dotest(testcase,inlist,0)

def test3(testcase):
  inlist = []
  dotest(testcase,inlist,0)

def dotest(testcase,inlist,expected):
  actual = count_odds(inlist)
  if actual != expected:
    msg = makeMessage(inlist,expected,actual,"Expected and actual values are not equal")
    testcase.fail(msg)

def makeMessage(inlist, expected,actual,explanation):
  bar ="\n###########EXPLANATION##########\n"
  msg = bar + "Function call: " + callToStr("count_odds", inlist) 
  msg += "\nExpected return value: " + repr(expected)
  msg += "\nActual return value: " + repr(actual)
  msg += "\n" + explanation + bar
  return msg

def callToStr(functor,*args):
  call = functor + "("
  nbrArgs = len(args)
  for i in range(0,nbrArgs):
    call += repr(args[i])
    if i == nbrArgs-1:
      call += ")"
    else:
      call += ","
  return call