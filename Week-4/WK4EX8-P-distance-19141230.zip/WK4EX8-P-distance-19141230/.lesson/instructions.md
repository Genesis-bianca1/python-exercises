## Week 4: Portfolio Exercise 1

Write a function that takes four parameters `x1,y1,x2,y2` and returns the distance between two points at co-ordinates `(x1,y1)` and `(x2,y2)`. This can be calculated using the formula

![dist = sqrt((x1-x2)**2 + (y1-y2)**2)](./assets/pyth_bigger.png)

**Hint #1:** Ensure that the first line of your Python file is
```
import math
```
so that you can use the function `math.sqrt` to calculate the square root of a number.

**Hint #2:** In Python you can use the operator `**` to raise one number to the power of another. For example `3**2` evaluates to `9` because 9 is the square of 3.

**Hint #3**: Remember that the function should **return** the distance, not print it out.



Example of use (in a Python console):
```
>d = distance(1,2,4,6)
>print(d)
5.0
```

## Explanation of automated tests

The arguments passed to the function during the tests, and the expected return values are shown below.

| Test| Arguments (x1,y1,x2,y2)| Expected return value | 
| --- | ---  | --- |
| test_1 | 1,2,4,6 | 5 | 
| test_2 | -1,-4,1,5| 9.21954 |
| test_3 | 0,0,0,0 | 0 |

The tests pass if the actual return value is within 0.05 of the expected return value.