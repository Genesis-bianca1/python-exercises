from main import distance

def test1(testcase):
  doTest(testcase,1,2,4,6,5)

def test2(testcase):
  doTest(testcase,-1,-4,1,5,9.21954)

def test3(testcase):
  doTest(testcase,0,0,0,0,0)

def doTest(testCase,x1,y1,x2,y2,expected):
  actual = distance(x1,y1,x2,y2)
  if not isinstance(actual,(float,int)):
    explanation = "Return value is not numeric"
    msg = makeMessage(x1,y1,x2,y2, expected,actual,explanation)
    testCase.fail(msg)
  if abs(expected - actual) > 0.05:
    msg = makeMessage(x1,y1,x2,y2, expected,actual,"Actual and expected return values are not equal")
    testCase.fail(msg)

def makeMessage(x1,y1,x2,y2, expected,actual,explanation):
  bar ="\n########EXPLANATION###############\n"
  msg = bar + "Function call: " + callToStr("distance", x1,y1,x2,y2) 
  msg += "\nExpected return value: " + repr(expected)
  msg += "\nActual return value: " + repr(actual)
  msg += "\n" + explanation + bar
  return msg

def callToStr(functor,*args):
  call = functor + "("
  nbrArgs = len(args)
  for i in range(0,nbrArgs):
    call += repr(args[i])
    if i == nbrArgs-1:
      call += ")"
    else:
      call += ","
  return call
