## Instructions
If you want to send an item to the US by Royal Mail as a &quot;letter&quot; it must meet the following criteria (which you can find at https://www.royalmail.com/price-finder):

- Max weight 100g
- Max length: 240mm
- Max width: 165mm
- Max depth: 5mm
- Both the length and the width must be at least 90mm
- One of the dimensions must be 140mm or greater

Write a **function** `is_letter` that takes the weight, length, width, and depth of an item as parameters (in that order, with weight expressed in g, and the other dimensions in mm) and **returns** `True` if the item can be sent as a letter and `False` otherwise.

## Example of use (in Python console)
```
> check = is_letter(100,240,165,5)
> print(check)
True
```
**Hint:** You may find that the built-in Python functions `min` and `max` are useful.

## Explanation of automated tests

The arguments passed to the function during the tests, and the expected return values are shown below.

| Test| Arguments (weight, length, width, depth)| Expected return value | 
| --- | ---  | --- |
| test_1 | 100,240,165,5| True | 
| test_2 | 101,240,165,5| False |
| test_3 | 100,241,165,5| False |
| test_4 | 100,240,166,5| False|
| test_5 | 100,240,165,6| False|
| test_6 | 100,140,90,5| True|
| test_7 | 100,90,140,5| True|
| test_8 | 100,140,89,5| False|
| test_9 | 100,89,140,5| False|
| test_10 |100,139,139,5| False|
