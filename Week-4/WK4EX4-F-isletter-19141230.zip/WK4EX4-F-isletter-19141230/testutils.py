#IMPORTANT: DO NOT CHANGE THIS FILE!
from main import is_letter

def test1(testCase):
  doTest(testCase, 100,240,165,5,True)

def test2(testCase):
  doTest(testCase, 101,240,165,5,False)

def test3(testCase):
  doTest(testCase, 100,241,165,5,False)

def test4(testCase):
  doTest(testCase, 100,240,166,5,False)

def test5(testCase):
  doTest(testCase, 100,240,165,6,False)

def test6(testCase):
  doTest(testCase, 100,140,90,5,True)

def test7(testCase):
  doTest(testCase, 100,90,140,5,True)

def test8(testCase):
  doTest(testCase, 100,140,89,5,False)

def test9(testCase):
  doTest(testCase, 100,89,140,5,False)

def test10(testCase):
  doTest(testCase, 100,139,139,5,False)


def doTest(testCase,weight,length,width,depth,expected):
  actual = is_letter(weight,length,width,depth)
  if not isinstance(actual,bool):
    explanation = "Return value is not Boolean"
    msg = makeMessage(weight,length,width,depth, expected,actual,explanation)
    testCase.fail(msg)
  if expected != actual:
    msg = makeMessage(weight,length,width,depth, expected,actual,"Actual and expected return values are not equal")
    testCase.fail(msg)


def makeMessage(weight,length,width,depth, expected,actual,explanation):
  bar ="\n##################################\n"
  msg = bar + "Function call: " + callToStr("is_letter", weight,length,width,depth) 
  msg += "\nExpected return value: " + repr(expected)
  msg += "\nActual return value: " + repr(actual)
  msg += "\n" + explanation + bar
  return msg

def callToStr(functor,*args):
  call = functor + "("
  nbrArgs = len(args)
  for i in range(0,nbrArgs):
    call += repr(args[i])
    if i == nbrArgs-1:
      call += ")"
    else:
      call += ","
  return call