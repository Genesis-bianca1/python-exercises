#IMPORTANT: DO NOT CHANGE THIS FILE!
from main import prod3

def test1(testCase):
  doTest(testCase, 2,3,4,24)

def test2(testCase):
  doTest(testCase, 2,0,4,0)

def test3(testCase):
  doTest(testCase,3,-1.5,1,-4.5)

def doTest(testCase,n1,n2,n3,expected):
  delta = 0.05
  actual = prod3(n1,n2,n3)
  if not isinstance(actual,(int,float)):
    explanation = "Return value is not a number"
    msg = makeMessage(n1,n2,n3,expected,actual,explanation)
    testCase.fail(msg)
  if abs(expected - actual) > delta:
    msg = makeMessage(n1,n2,n3,expected,actual,"Actual and expected return values are not equal")
    testCase.fail(msg)


def makeMessage(n1,n2,n3,expected,actual,explanation):
  bar ="\n##################################\n"
  msg = bar + "Function call: " + callToStr("prod3",n1,n2,n3) 
  msg += "\nExpected return value: " + repr(expected)
  msg += "\nActual return value: " + repr(actual)
  msg += "\n" + explanation + bar
  return msg

def callToStr(functor,*args):
  call = functor + "("
  nbrArgs = len(args)
  for i in range(0,nbrArgs):
    call += repr(args[i])
    if i == nbrArgs-1:
      call += ")"
    else:
      call += ","
  return call


