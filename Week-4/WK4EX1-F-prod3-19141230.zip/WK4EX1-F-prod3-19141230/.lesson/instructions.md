# Exercise 1

Write a function `prod3` so that returns the product of three numbers. For example, `prod3(2,3,4)` would return `24`. N.B. the function should **return** the product of the numbers, not print it out.

**Note:** The function should **not** be made conditional on  `if __name__ == "__main__":`  That is something we do for programs, not functions.

## Example of use (in Python Console)
```
> n = prod3(4,-3,2)
> print(n)
-24

```

## Explanation of automated tests

The arguments passed to the function during the tests, and the expected return values are shown below

| Test| Arguments| Expected return value | 
| --- | ---  | --- |
| test_1 | 2,3,4| 24 | 
| test_2 | 2,0,4| 0 |
| test_3 | 3,-1.5,1| -4.5 |
