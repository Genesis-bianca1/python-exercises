#IMPORTANT: DO NOT CHANGE THIS FILE!
from main import prodlist

def test1(testCase):
  doTest(testCase, [],1)

def test2(testCase):
  doTest(testCase, [3.5],3.5)

def test3(testCase):
  doTest(testCase,[3,-1.5,1],-4.5)

def doTest(testCase,numList,expected):
  delta = 0.05
  actual = prodlist(numList)
  if not isinstance(actual,(int,float)):
    explanation = "Return value is not a number"
    msg = makeMessage(numList, expected,actual,explanation)
    testCase.fail(msg)
  if abs(expected - actual) > delta:
    msg = makeMessage(numList, expected,actual,"Actual and expected return values are not equal")
    testCase.fail(msg)


def makeMessage(numList, expected,actual,explanation):
  bar ="\n##################################\n"
  msg = bar + "Function call: " + callToStr("prodlist", numList) 
  msg += "\nExpected return value: " + repr(expected)
  msg += "\nActual return value: " + repr(actual)
  msg += "\n" + explanation + bar
  return msg

def callToStr(functor,*args):
  call = functor + "("
  nbrArgs = len(args)
  for i in range(0,nbrArgs):
    call += repr(args[i])
    if i == nbrArgs-1:
      call += ")"
    else:
      call += ","
  return call