## Instructions

The `split` method can be used on a string containing words separated by whitespace and turns it into a list containing those words, as illustrated below (using the Python console).
```
>phrase = 'Hello there'
>words = phrase.split()
>words
['Hello','there']
```

The operator `in` can be used to find whether a word contains a given substring. Example of use:

```
> 'an' in 'sandman'
True
> 'snow' in 'sandman'
False
```

Using these features of Python, write a program that allows the user to maintain a list of words. The program should work as follows:

- The user is repeatedly prompted to enter a command (the prompt should be `Your command: ` and you should include a space character at the end). The user responds by entering a one- or two-word command. The commands can be of the following form:
  - The word `add`, followed by another word of the user&#39;s choice. This word should then be added to the end of the list that is being maintained by the program.
  - The word `find`, followed by an string. The program should then print out all the words in the list that contain this string
  - The word `quit`. When this is typed, the program should finish.



You do not, at this stage, need to handle the case where the user enters invalid input (you can do that if it makes your life easier, but be careful not to overcomplicate your code). 

**Note:** The words `add`, `find`, and `quit` must be alll lower case.

An example run is shown below

```
Your command: add mouse
Your command: add add
Your command: add find
Your command: add cat
Your command: add smart
Your command: add bat
Your command: add tart
Your command: find at
cat
bat
Your command: find fin
find
Your command: find art
smart
tart
Your command: quit
```

**Hint:** If your program goes into an infinite loop, you can exit the loop by typing Ctrl-C in the Python console.

# Explanation of automated tests

There are two tests. The easiest way to pass them is to arrange that your program expects input, and produces output, in exactly the format illustrated by the example of use.

**Note:** Make sure the prompt `Your command: ` ends with a space character.

  
**Test 1** runs your program with the following input:

```
add mouse
add cat
add smart
add  find
add  add
add bat
add fish
find add
find find
find at
add sat
add tart
find art
quit
```
The test is passed if:
* the output contains the words `add`,`find`,`cat`,`bat`,`smart`, and `tart`, in that order, and
* the output does **not** contain any of the other strings that followed the words `add` or `find` in the input.

**Test 2** runs your program with the following input. 

```
add house
add cottage
add shed
find house
add hovel
find h
find villa
add villa
quit
```
The test is passed if:
* the output contains the words `house`,`house`,`shed`,and `hovel`, in that order, and
* the output does **not** contain any of the other strings that followed the words `add` or `find` in the input.
