import io
import sys
import re
from contextlib import redirect_stdout

def test1(testCase):
  inputStr = "add mouse\nadd cat\nadd smart\nadd  find\nadd  add\nadd bat\nadd fish\nfind add\nfind find\nfind at\nadd sat\nadd tart\nfind art\nquit"
  outputStr = runMain(inputStr)
  wordSet = {'find','add','mouse','cat','smart','bat','fish','sat','tart','at','art'}
  outWords = ['add','find','cat','bat','smart','tart']
  analyseOutput(testCase,inputStr,outputStr,wordSet,outWords)

def test2(testCase):
  inputStr = "add house\nadd cottage\nadd shed\nfind house\nadd hovel\nfind h\nfind villa\nadd villa\nquit"
  outputStr = runMain(inputStr)
  wordSet = {'house','cottage','shed','hovel','villa','h'}
  outWords = ['house','house','shed','hovel']
  analyseOutput(testCase,inputStr,outputStr,wordSet,outWords)
  
def analyseOutput(testCase, inputStr, outputStr,words,expectedOrder):
  outSplit = re.split('\W+',outputStr)
  actualOrder = []
  for word in outSplit:
    if word in words:
      actualOrder.append(word)
  if actualOrder != expectedOrder:
    message = makeExplanation(inputStr,outputStr, words, expectedOrder, actualOrder)
    testCase.fail(message)

def makeExplanation(inputStr,outputStr,words,expectedOrder, actualOrder):
  bar = "\n#########EXPLANATION##########\n"
  msg = bar + "Test input was:\n"
  msg += inputStr
  msg += "\n\nOutput was:\n"
  msg += outputStr
  msg += "\n\nExpected that output would contain (in this order)\n"
  for word in expectedOrder:
    msg += word + " "
  msg += "\n\nExpected that output would NOT contain the following words\n"
  for word in words:
    if word not in expectedOrder:
      msg += word + " "
  
  msg += "\n\nActually found the following words in output (in this order)\n"
  for word in actualOrder:
    msg += word + " "
  msg += bar
  return msg

def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
	  exec(mainfile.read(),{ "__name__":"__main__"})
  mainfile.close()
  return output.getvalue()
