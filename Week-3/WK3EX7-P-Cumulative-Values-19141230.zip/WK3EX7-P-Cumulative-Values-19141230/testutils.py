import io
import re
import sys
from contextlib import redirect_stdout

def test1(testcase):
  doTest(testcase,[-1],[])

def test2(testcase):
  doTest(testcase,[2,-1],[2])

def test3(testcase):
  doTest(testcase,[5,1,7,2,3,-1],[5,6,13,15,18])

def test4(testcase):
  doTest(testcase,[8,99,2,1,1,5,-1],[8,107,109,110,111,116])

def doTest(testcase, inputs, cumulatives):
  inputStr = ""
  for num in inputs:
    inputStr += str(num) + '\n'
  outputStr = runMain(inputStr)
  analyseOutput(testcase, inputStr, outputStr, cumulatives)

def analyseOutput(testcase, inputStr, outputStr, cumulatives):
  outputSplit = outputStr.split()
  index = len(outputSplit) - 1
  unsigned = []
  #Add unsigned integers to the beginning of the array 'unsigned', until you find something that is not an unsigned integer
  while index > 0 and isUnsignedInteger(outputSplit[index]):
    unsigned.insert(0,int(outputSplit[index]))
    index -= 1
  explanation = ""
  if unsigned != cumulatives:
    explanation += "\nDid not see correct sequence of integers\n"
  if index == 0:
    explanation += "\nDid not see anything that looked like an input prompt\n"
  if explanation != "":
    msg = explainError(inputStr,outputStr,unsigned,cumulatives,explanation)
    testcase.fail(msg)    
  
def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
	  exec(mainfile.read(),{ "__name__":"__main__"})
  mainfile.close()
  return output.getvalue()

def isUnsignedInteger(str):
  regex = '\d+'
  return re.fullmatch(regex,str) != None


def explainError(input,output,unsigned,cumulatives, explanation):
  bar = '\n######################EXPLANATION##################\n'
  message = bar + "INPUT:\n"
  message += input
  message += "\nOUTPUT\n"
  message += output
  message += "\nUnsigned integers extracted from output:\n"
  message += listNums(unsigned)
  message += "\nExpected to see the following unsigned integers:\n"
  message += listNums(cumulatives)
  message += '\n' + explanation + '\n'
  message += bar
  return message

def listNums(numList):
  strList = ""
  for num in numList:
    strList += str(num) + " "
  return strList
    
