## Instructions
Write a program that invites the user to enter a sequence of unsigned integer values, terminated by `-1`. And then writes output such that the `n`th number in the output is the sum of the first `n` numbers in the input (do not include the terminating value `-1`).

**Example Run:**
```
Enter an unsigned integer (or -1 to finish): 4
Enter an unsigned integer (or -1 to finish): 5
Enter an unsigned integer (or -1 to finish): 1
Enter an unsigned integer (or -1 to finish): 2
Enter an unsigned integer (or -1 to finish): -1
Cumulative values:
4
9
10
12
```

## Explanation of automated tests

The test data used is shown below. Note that in test_1 we expect to see no unsigned integers in the output.

| Test | Input Values | Expected Unsigned Integers in Output | 
| --- | ---  | --- |
| test_1 | -1 |  |
| test_2 | 2, -1 | 2 |
| test_3 | 5, 1, 7, 2, 3, -1 | 5, 6, 13, 15, 18 |
| test_4 | 8, 99, 2, 1, 1, 5, -1 | 8, 107, 109, 110, 111, 116 |


The easiest way to pass the automated tests is to produce output of exactly the form illustrated in the examples of use. However the tests will pass provided that:
* the expected unsigned integers appear, in the correct order, at the end of the output with only white space between them.
* There is some text in the output, but all this text appears **before** the unsigned integers.

This means that you must prompt the user to enter values (otherwise there would be no text in the output) but all of the cumulative values are output after **all** of the input has been provided.

**Note:** The unsigned integers in the output should be surrounded by white space. The easiest way to do do this is probably to ensure that each such number is output on a separate line, as in the example of use.
