import io
import sys
import re
from contextlib import redirect_stdout

def test1(testCase):
  mainfile = open('main.py')
  programText = mainfile.read()
  progSplit = programText.split()
  if 'for' not in progSplit and 'while' not in progSplit:
    bar = '\n#######################################################\n'
    msg = bar + "Neither the word 'for' or the word 'while' are found in your program. It doesn't look as if you are using a loop!"+ bar
    testCase.fail(msg)

def test2(testCase):
  for i in range(0,20):
    doTest2(testCase)

def doTest2(testCase):
  outputStr = runMain("")
  ints = getInts(outputStr)
  if len(ints) < 10:
    msg = makeMessage([outputStr], "Expected that output would  at least 10 integers, but found fewer!")
    testCase.fail(msg)
  firstList = ints[:10]
  outOfRangeFirst = [num for num in firstList if num < 0 or num > 99]
  if len(outOfRangeFirst) != 0:
    msg = makeMessage([outputStr], "First list contains values that are outside range 0-99")
    testCase.fail(msg)
  secondList = ints[10:-1]
  outOfRangeSecond = [num for num in secondList if num < 50 or num > 99]
  if len(outOfRangeSecond) != 0:
    msg = makeMessage([outputStr], "Second list contains values that are outside range 50-99")
    testCase.fail(msg)
  diff = [num for num in secondList if num not in firstList]
  if len(diff) != 0:
    msg = makeMessage([outputStr], "Second list contains values that are not in the first list")
    testCase.fail(msg)

def test3(testCase):
  out1 = runMain("")
  out2 = runMain("")
  ints1 = getInts(out1)
  ints2 = getInts(out2)
  if ints1 == ints2:
    explanation = "Ran the program twice and got exactly the same output both times, that is highly unlikely if the output is genuinely random"
    msg = makeMessage([out1,out2],explanation)
    testCase.fail(msg)

def test4(testCase):
  nbrRuns = 4
  outputs = [runMain("") for x in range (0,nbrRuns)]
  unflat = [getInts(output) for output in outputs]
  ints = flatten(unflat)
  small = [n for n in ints if n < 50]
  big = [n for n in ints if n > 50]
  if len(small) == 0 or len(big) == 0:
    explanation = "Ran program " + str(nbrRuns) + " times. Would expect to see some values < 50 and some values > 50, but didn't!"
    msg = makeMessage(outputs, explanation)
    testCase.fail(msg)


def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
	  exec(mainfile.read(),{ "__name__":"__main__"})
  mainfile.close()
  return output.getvalue()

def isInteger(str):
  regex = '[-+]?\d+'
  return re.fullmatch(regex,str) != None

def makeMessage(outputs, explanation):
  bar = "\n######################################################"
  msg = bar
  nbrOuts = len(outputs)
  for i in range(1,nbrOuts + 1):
     msg += "\nOutput from run " + (str(i) if nbrOuts > 1 else "") + " was:\n" + outputs[i-1] 
  msg += "\n" + explanation + bar
  return msg

def getInts(outputStr):
  outSplit = re.split('[+-]?\D+',outputStr)
  ints = [int(word) for word in outSplit if isInteger(word)]
  return ints

def flatten(alist):
  return [x for sub in alist for x in sub]