## Instructions

In an earlier exercise, you wrote a loop that prints out a sequence of ten random numbers. Modify this is exercise so that it puts all ten numbers picked into a list and then prints out: first all the numbers in the list, then all those numbers that are greater than or equal to 50. An example run is shown below.
## Example run
```
Complete list:  [57, 71, 92, 62, 30, 49, 6, 42, 78, 62]
Of which:  [57, 71, 92, 62, 78, 62] are >= 50
```

**Programming hints:**

An empty list can be created like this

`numList = []`

A value (in this example the number 8) can be appended to a list like this

`numList.append(8)`

The statement `print(numList)` will print out all the values in `numList`, enclosed in square brackets and separated by commas in the manner shown in the box above.

## Explanation of automated tests
There are four automated tests

**Test 1:** Tests whether the program uses a loop by checking that either the word `for` or the word `while` occurs in it. 

**Test 2:** Performs the following sequence of operations 20 times:
* Runs the program, checks that the output contains at least 10 integers, and splits up the output into two lists. The first list contains the first ten integers found, the second contains all the other integers except the last (if your program has output in the same format as the example run the last integer is always 50).
* Checks that all integers in the first list are in the range 0-99 and that all integers in the second list are in the range 50-99.
* Checks that all integers in the second list also appear in the first.

**Test 3:** Tests for randomness by running the program twice and checking that the output produced by the second run is not identical to that produced by the first.

**Test 4:** Tests for randomness by running the program four times and checking that at least one of the output integers is greater than 50 and at least one is less than 50.

**Note #1** The complete list (i.e. the first one you  print out) should contain exactly ten numbers, otherwise it is likely that test 2 will fail.

**Note #2** It is theoretically possible for a correct program to fail Test 3 or Test 4 because it just happened to produce output that fails those tests. As explained in the notes for the earlier exercise (the one where you simply printed out a list of random numbers), the probability of a correct program failing the tests purely by chance is so small that it can be ignored.