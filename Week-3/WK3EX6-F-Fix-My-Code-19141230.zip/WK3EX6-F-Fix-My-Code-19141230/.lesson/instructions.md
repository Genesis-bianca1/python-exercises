## Instructions
__Note__: There are no automated tests for this exercise.

The program in the file main.py is meant to reverse a list, but it doesn't work. Explain why it does not work. Then fix the error, with as little modification to the code as possible.

N.B. If you have read around the topic, you may realise that you could reverse the list just using

`s = s[::-1]`

We don't want you to do that! We want you to explain *why* the code presented did not work. Then we want you to modify the code so that it still contains a loop, but a loop that works!

__Hint__: You can add extra print statements to the program to show the values that variables take during execution. Remember to remove them from any finished program though.

You could also try using the Replit debugger to step through the program. However it does not always work well. If you do adopt this strategy, have pencil and paper handy to make a note of the values that variables take on each iteration of the loop, and to calculate the values of relevant expressions. 