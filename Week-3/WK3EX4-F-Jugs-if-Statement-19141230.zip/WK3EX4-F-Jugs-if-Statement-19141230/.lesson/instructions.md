# Instructions

This exercise is related to the water jugs problem from last week&#39;s class. You do **not** need to use a loop to execute it. You just need to remember how to use `if` statements. We will return to the jugs problem later in the module and, when we do, you will need to use loops.

Write a program that:

1. Asks the user for the capacities of two jugs, A and B
2. Asks the user how much water is initially in each jug
3. Asks the user to choose one of the following operations:
   * FA (fill jug A from tap)
   * FB (fill jug B from tap)
   * EA (empty jug A)
   * EB (empty jug B)
   * AB (transfer as much water as possible from jug A to jug B)
   * BA (transfer as much water as possible from jug B to jug A)
4. Displays the volumes in the two jugs after the chosen operation has been performed.

**Programming hint:** you may find that it is useful to use the Python function `min`, which can be used to calculate the minimum of two numbers, for example

`x = min(5,3)`

results in `x` being assigned the value `3`

## Example of use
```
Capacity of jug A? 5
Capacity of jug B? 3
Number of litres in jug A? 4
Number of litres in jug B? 2
Operations are:
FA (fill jug A)
FB (fill jug B)
EA (Empty jug A)
EB (Empty jug B)
AB (Transfer as much water as possible from jug A to jug B)
BA (Transfer as much water as possible from jug B to jug A)
Which operation do you want to perform? BA
After operation:
5  litres in jug A
1  litres in jug B
```

## Explanation of automated tests

The test data used is shown below

| Test| Capacities of jugs A,B| Initial volumes of water in jugs A,B | Option chosen  |Expected final volumes in jugs A,B |
| --- | ---  | --- |--- |  --- |
| test_1 | 6,4| 3,1 | `FA` | 6,1|
| test_2 | 5,3| 2,1 | `FB` | 2,3|
| test_3 | 8,9| 7,5 | `EA` | 0,5|
| test_4 | 5,3| 2,1 | `EB` | 2,0|
| test_5 | 7,5| 3,4 | `AB` | 2,5|
| test_6 | 7,5| 2,1 | `AB` | 0,3|
| test_7 | 5,4| 3,4 | `BA` | 5,2|
| test_8 | 5,4| 2,4 | `BA` | 5,1|

The easiest way to pass the automated tests is to produce output of exactly the form illustrated in the examples of use. However the tests will pass if:
* The input consists of: The capacity of jug A; the capacity of jug B; the initial volume in jug A; the initial volume in jug B; and the option chosen by the user (either `FA`, `FB`, `EA`, `EB`, `AB`, or `BA`) in that order.
* The last two integers integers found in the output are the final volumes of water in jugs A and B, in that order.
