import io
import sys
import re
from contextlib import redirect_stdout

def test1(testCase):
  doTest(testCase,6,4,3,1,"FA",6,1)
def test2(testCase):
  doTest(testCase,5,3,2,1,"FB",2,3)
def test3(testCase):
  doTest(testCase,8,9,7,5,"EA",0,5)
def test4(testCase):
  doTest(testCase,5,3,2,1,"EB",2,0)
def test5(testCase):
  doTest(testCase,7,5,3,4,"AB",2,5)
def test6(testCase):
  doTest(testCase,7,5,2,1,"AB",0,3)
def test7(testCase):
  doTest(testCase,5,4,3,4,"BA",5,2)
def test8(testCase):
  doTest(testCase,5,4,2,4,"BA",5,1)

def doTest(testCase, capA, capB,initVolA,initVolB, op, finalVolA, finalVolB):
  inputStr = str(capA) + '\n' + str(capB) + '\n' + str(initVolA) + '\n' + str(initVolB) + '\n' + op + '\n'
  outputStr = runMain(inputStr)
  analyseOutput(testCase, inputStr, outputStr, finalVolA, finalVolB)

def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
	  exec(mainfile.read(),{ "__name__":"__main__"})
  mainfile.close()
  return output.getvalue()

def analyseOutput(testCase, inputStr, outputStr, finalVolA, finalVolB):
  ints = getInts(outputStr)
  if len(ints) < 2:
    msg = makeMessage(inputStr, outputStr,  finalVolA, finalVolB, "Needed at least two integers in output. Didn't find them!")
    testCase.fail(msg)

  if ints[-2] != finalVolA or ints [-1] != finalVolB:
    msg = makeMessage(inputStr, outputStr, finalVolA, finalVolB, "The final volumes in the jugs are not as expected!")
    testCase.fail(msg)

def makeMessage(inputStr, outputStr, finalVolA, finalVolB, explanation):
  bar = "\n######################################################\n"
  msg = bar + "Test input was:\n" + inputStr
  msg += "\nOutput was:\n" + outputStr 
  msg += "\nExpected final volume in jug A: " + str(finalVolA)
  msg += "\nExpected final volume in jug B: " + str(finalVolB)
  msg += "\n" + explanation + bar
  return msg

def getInts(string):
  split = re.split('[^0-9+\-]',string)
  ints = [int(word) for word in split if isInteger(word)]
  return ints

def isInteger(str):
  regex = '[-+]?\d+'
  return re.fullmatch(regex,str) != None