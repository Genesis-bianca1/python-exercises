if __name__ == "__main__":
  powers_list = [2**i for i in range(1,11)]
  
  index=0
  for index in powers_list:
    print(index)