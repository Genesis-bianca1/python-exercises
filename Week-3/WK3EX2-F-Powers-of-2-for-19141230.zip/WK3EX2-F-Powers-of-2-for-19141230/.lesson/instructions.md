# Instructions

Using a `for` loop, write a program that prints out the first 10 powers of 2. 

In other words, the output should be:

```
2
4
8
16
32
64
128
256
512
1024
```

## Explanation of automated tests

There are two automated tests. The first checks that the output contains the right numbers, in the right order. The second checks that your program includes the word `for` (although it won't check that you are using it correctly!).