import io
import sys
import re
from contextlib import redirect_stdout

def test1(testCase):
  outputStr = runMain("")
  analyseOutput(testCase, outputStr)

def test2(testCase):
  mainfile = open('main.py')
  programText = mainfile.read()
  progSplit = programText.split()
  if 'for' not in progSplit:
    bar = '\n#######################################################\n'
    msg = bar + 'You do not appear to be using a for loop!' + bar
    testCase.fail(msg)

def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
	  exec(mainfile.read(),{ "__name__":"__main__"})
  mainfile.close()
  return output.getvalue()

def analyseOutput(testCase, outputStr):
  expectedInts = [2,4,8,16,32,64,128,256,512,1024]
  outSplit = re.split('\s+',outputStr)
  ints = []
  for word in outSplit:
    if isInteger(word):
      ints.append(int(word))
  
  if ints != expectedInts:
    msg = makeMessage(outputStr, "Output is not what was expected")
    testCase.fail(msg);

def makeMessage(outputStr, explanation):
  msg = "\n######################################################"
  msg += "\nOutput from test was:\n" + outputStr 
  msg += "\n" + explanation
  msg += "\n######################################################\n"
  return msg

def isInteger(str):
  regex = '[-+]?\d+'
  return re.fullmatch(regex,str) != None