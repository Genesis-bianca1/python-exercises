## Instructions

Adding the line `import random` at the beginning of a Python program makes it possible to perform various random operations. In particular it allows you to use the function `random.randint`. If `a` and `b` are integers then the expression `random.randint(a, b)` evaluates to a random integer _N_ such that `a` &lt;= _N_ &lt;= `b`.

The program in the file main.py  illustrates the use of `random.randint`. Run it a few times to make sure you understand how it works.

Once you have understood the program in main.py, replace it with a program that prints 10 randomly chosen integers, in the range 0 to 99 (inclusive). You should use a loop, rather than writing 10 separate print statements. 

**N.B.** Once you have understood the code that I have placed in main.py, you must **delete** it before replacing it with your own code. If you leave my code in the program, the automated tests will fail!

## Example of use
```
47
6
49
34
61
53
60
45
59
5
```
## Explanation of automated tests
There are four automated tests

**Test 1:** Tests whether the program uses a loop by checking that either the word `for` or the word `while` occurs in it. 

**Test 2:** Checks that 10 integers are output and that all these integers are in the range 0-99 (inclusive)

**Test 3:** Tests for randomness by running the program twice and checking that the output produced by the second run is not identical to that produced by the first.

**Test 4:** Tests for randomness by running the program four times and checking that at least one of the output integers is greater than 50 and at least one is less than 50.

**Note:** It is theoretically possible for a correct program to fail test 3 or test 4 because it just happened to produce output that fails those tests. But the probability of failing test 3 purely by chance is 1 in 10,000,000,000 and the probability of failing test 4 purely by chance is about 2 in 1,000,000,000,000. If either of those things happen to you then you it is likely that you are immune to the usual laws of probability, so go out and buy a lottery ticket. Better still, go out and buy a lottery ticket, then give it to me!