import pandas as pd
from matplotlib import pyplot as plt

if __name__ == "__main__":
  ge2019 = pd.read_csv('ge2019.csv')
  edu = pd.read_csv('education.csv')
  ge2019 = ge2019[['ons_id', 'Name', 'electorate', 'valid_votes', 'majority']]
  ge2019 = ge2019.assign(turnout=ge2019['valid_votes'] / ge2019['electorate'])
  ge2019 = ge2019.assign(majpc=ge2019['majority'] / ge2019['valid_votes'])
  ge2019['Name'] = ge2019['Name'].str.strip()
  ge2019['Name'] = ge2019['Name'].str.lower()
  edu['Name'] = edu['Name'].str.strip()
  edu['Name'] = edu['Name'].str.lower()
  joint = pd.merge(ge2019, edu, on='Name')
  plot = plt.subplots(nrows=1, ncols=2)
  axes = plot[1]
  joint.plot(x='Cons%',
             xlabel='Educated to Level 4 Or Above',
             y='turnout',
             kind='scatter',
             ax=axes[0],
             title='Turnout vs Education')
  joint.plot(x='majpc',
             xlabel="Majority",
             y='turnout',
             kind='scatter',
             ax=axes[1],
             title='Turnout vs Majority',
             sharey=True)
  # If you wish to save the figure, then replace line below with
  #plt.savefig("fig")
  plt.show()
