## Instructions
This project contains:

* The Python file from the case study
* The files education.csv and ge2019.csv from the case study
* A file no_vehicles.csv. This file was derived from the same source as education.csv It has the following columns
  * **Cars in the household:** This always has the value 'No cars or vans in household' (the data were extracted from a larger spreadsheet).
  * **Name:** The constituency name
  * **NVFraction:** The fraction of households in the constituency that do not own a car or van

Use this data to obtain scatter diagrams, similar to those in the case study, showing:
* The turnout vs. the fraction of households that **do** own at least one car or van.
* The fraction of households that **do** own at least one car or van versus the fraction of adults educated to level 4 above.

**Note:** The file no_vehicles.csv lists the fraction of households that do **not** own a car or van. You will need to subtract this from 1 in order to get the fraction that do own a car or van.

**Hint #1:** If you are finding visualisation of the graph fiddly then you can replace `plt.show()` with `plt.savefig("fig")`. This saves the figure to a file fig.png, which you can view at your leisure.

**Hint #2:** You won't be able to use `sharey=True` when plotting the graphs, because they don't share the same y axis

**Hint #3:** If you find that the graphs overlap each other, call `plt.tight_layout()` before displaying (or saving) the figure.