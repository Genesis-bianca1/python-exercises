## Instructions

If you wish to send a cylindrical package to the USA by Royal Mail, then it must meet the following criteria (set out at https://send.royalmail.com/send/youritem?country=USA&amp;weight=190&amp;weightUnit=G):

- The weight must be no more than 2000g
- The length must be no more than 90cm
- The length + twice the diameter must be no more than 104cm.

Write a program that requires the user to input the weight as an integer (in g), the length as an integer (in cm) and then the diameter as an integer (also in cm). The program should output either `Yes` or `No` depending on whether the package meets the rules.

Note that, in order to pass the automated tests, the input must be in the order weight, then length, then diameter, and the output must contain the words `Yes` or `No`. Here are a couple of example runs of a suitable program.

### Example Run #1
```
Enter weight (g):2000
Enter length (cm):90
Enter diameter (cm):7
Yes
```
### Example Run #2
```
Enter weight (g):2000
Enter length (cm):90
Enter diameter (cm):8
No
```

## Explanation of automated tests

The test data used is shown below

| Test| Weight| Length| Diameter  |Expect Output Will End With |
| --- | ---  | --- |--- |  --- |
| test_1 | `2000`| `90` | `7` | `Yes` |
| test_2 | `2001`| `90` | `7` |`No` |
| test_3 | `2000`| `91` | `7` |`No` |
| test_4 | `2000`| `90` | `8` |`No` |
| test_5 | `2000`| `101` | `2` |`No` |
| test_6 | `2000`| `4` | `50` |`Yes` |


The easiest way to pass the automated tests is to produce output of exactly the form illustrated in the examples of use. However the tests will pass if the output ends with the appropriate string (`Yes` or `No` as indicated in the table above). Note that this is case sensitive, for example `Yes` or `No` will work, but `yes` or `no` will not.