import io
import sys
from contextlib import redirect_stdout


def test1(testCase):
  inputStr = "2000\n90\n7\n"
  outputStr = runMain(inputStr)
  analyseOutput(testCase, inputStr, "Yes", outputStr)


def test2(testCase):
  inputStr = "2001\n90\n7\n"
  outputStr = runMain(inputStr)
  analyseOutput(testCase, inputStr, "No", outputStr)


def test3(testCase):
  inputStr = "2000\n91\n7\n"
  outputStr = runMain(inputStr)
  analyseOutput(testCase, inputStr, "No", outputStr)


def test4(testCase):
  inputStr = "2000\n90\n8\n"
  outputStr = runMain(inputStr)
  analyseOutput(testCase, inputStr, "No", outputStr)


def test5(testCase):
  inputStr = "2000\n101\n2\n"
  outputStr = runMain(inputStr)
  analyseOutput(testCase, inputStr, "No", outputStr)


def test6(testCase):
  inputStr = "2000\n4\n50\n"
  outputStr = runMain(inputStr)
  analyseOutput(testCase, inputStr, "Yes", outputStr)


def runMain(inputStr):
  output = io.StringIO()
  sys.stdin = io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
    exec(mainfile.read(), {"__name__": "__main__"})
  mainfile.close()
  return output.getvalue()


def analyseOutput(testCase, inputStr, expectedResult, outputStr):
  if not outputStr.strip().endswith(expectedResult):
    message = makeExplanation(inputStr, expectedResult, outputStr)
    testCase.fail(message)


def makeExplanation(inputStr, expectedResult, outputStr):
  msg = "\n#####################################################"
  msg += "\nTest input was:\n"
  msg += inputStr
  msg += "\nAcual output:" + outputStr
  msg += "\nExpected that actual output would end with:" + expectedResult
  return msg
