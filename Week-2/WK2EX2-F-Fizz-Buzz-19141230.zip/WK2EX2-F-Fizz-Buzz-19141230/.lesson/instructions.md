## Instructions

Write a program asks the user to enter a number using the prompt `Enter an integer:` and then...

- If the number is divisible by 3, outputs `Fizz`
- Else if the number is divisible by 5, outputs `Buzz`
- Else if the number is divisible by 3 and by 5, outputs `Fizz Buzz`
- If none of the above criteria are met, the program should just output the number.

**Programming hint:** The operator `%` (modulo) can be used to tell if one number is divisible by another. It gives the remainder after division, so `n` is divisible by `m` if, and only if, `n%m` is zero

**Important Note:** In order to pass the tests, the input prompt must end with a non-alphanumeric character, for example a space or a colon. For example `'Enter a number:'`, `'Enter a number '`, or `'Enter a number: '` should work, but `'Enter a number'` will not.

**Example Run #1**
```
Enter a number:9
Fizz
```
**Example Run #2**
```
Enter a number:25
Buzz
```
**Example Run #3**
```
Enter a number:30
Fizz Buzz
```
**Example Run #4**
```
Enter a number:23
23
```
## Automated Test Plan
The automated tests for this exercise work to the following plan:

|Test ID | Input | Expected Last Word(s) of Output |
|-- |--- | --- |
|test_1| `18` | `Fizz` |
|test_2| `10` | `Buzz` |
|test_3| `45` | `Fizz Buzz` |
|test_4| `41` | `41` | 

