import io
import sys
import re
from contextlib import redirect_stdout

def test1(testcase):
  doTest(testcase, 18, 'Fizz')
def test2(testcase):
  doTest(testcase, 10, 'Buzz')
def test3(testcase):
  doTest(testcase, 45, 'Fizz Buzz')
def test4(testcase):
  doTest(testcase, 41, '41')

def doTest(testcase, inputNbr, expectedOutput):
  inputStr = str(inputNbr) + '\n'
  outputStr = runMain(inputStr)
  expectedSplit = expectedOutput.strip().split()
  msg = explainInOut(inputStr, expectedOutput, outputStr)
  outSplit = re.split('\W+', outputStr.strip())
  if len(outSplit) < len(expectedSplit):
    msg += '\n:Not enough output expected at least ' + str(len(expectedSplit)) + ' words'
    testcase.fail(msg)
  elif len(expectedSplit) == 1:
    last = outSplit[-1]
    if not closeEnough(expectedSplit[-1],last):
      msg += "\nLast word of output was '" + last + "'"
      #msg += '\nLast word of output should be ' + expectedSplit[-1]
      testcase.fail(msg)
  elif len(expectedSplit) == 2:
    outLast = outSplit[-1]
    outPenult = outSplit[-2]
    expectLast = expectedSplit[-1]
    expectPenult = expectedSplit[-2]
    if not (closeEnough(expectLast,outLast) and closeEnough(expectPenult,outPenult)):
      #msg += '\nLast words of output should be ' + expectedSplit[-2] + ' ' + expectedSplit[-1]
      msg += "\nLast two words of output were '" + outPenult +  "', and '" + outLast + "'"
      testcase.fail(msg)
  
def closeEnough(expected, actual):
  return expected.strip().lower() == actual.strip().lower()
    
def explainInOut(inputStr, expectedOutputStr, actualOutputStr):
  msg = "\nInput was:\n" + inputStr +  "\nOutput was:\n" + actualOutputStr + "\nExpected output to end with:\n" + expectedOutputStr
  return msg

def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
	  exec(mainfile.read(),{ "__name__":"__main__"})
  mainfile.close()
  return output.getvalue()