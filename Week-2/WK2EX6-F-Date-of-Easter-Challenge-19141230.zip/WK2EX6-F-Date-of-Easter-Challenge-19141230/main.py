if __name__ == "__main__":
  month = [1,2,3,4,5,6,7,8,9,10,11,12]
  #day_of_easter_sunday = p + 1
  
  
  for n in month:
    if 2017 % n == 57:
      print(n)
  
  #year = int(input('Enter a year:'))