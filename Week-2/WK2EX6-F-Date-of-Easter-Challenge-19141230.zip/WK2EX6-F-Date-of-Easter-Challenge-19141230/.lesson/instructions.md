# Instructions

**Note: This exercise is difficult for beginner programmers! I will be impressed if you manage to complete it, but don&#39;t worry if you can&#39;t. Many thanks for David Lightfoot for suggesting it.**

The table overleaf shows an algorithm for calculating the date of (Western) Easter Sunday. It is taken from Astronomical Algorithms by Jean Meeus and is originally by Spencer Jones in General Astronomy, p73‐74, edition of 1922.

You do not need to understand what the variables mean, or how the algorithm has been arrived at!

| **Divide** | **By** | **Quotient** | **Remainder** |
| --- | --- | --- | --- |
| The year x | 19 | – | a |
| The year x | 100 | b | c |
| b | 4 | d | e |
| b + 8 | 25 | f | – |
| b ‐ f + 1 | 3 | g | – |
| 19a + b ‐ d ‐ g + 15 | 30 | – | h |
| c | 4 | i | k |
| 32 + 2e +2i ‐ h ‐ k | 7 | – | l |
| a + 11h + 22l | 451 | m | – |
| h + l ‐ 7m + 114 | 31 | n | p |

_n_ is the month and _p+1_ the day of the month of Easter Sunday

Here is an example calculation for 2017:

- remainder of 2017 divided by 19 is 3
- quotient of 2017 divided by 100 is 20
- remainder of 2017 divided by 100 is 17
- and so on as shown in the table below

| x | a | b | c | d | e | f | g | h | i | k | l | m | n | p |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2017 | 3 | 20 | 17 | 5 | 0 | 1 | 6 | 21 | 4 | 1 | 4 | 0 | 4 | 15 |

Easter Sunday was 2017‐04‐16

Write a Python program that prompts the user for a year and determines the date of Easter in that year according to the above instructions. You must make your program display the value of all the variables used as well.

**Programming hint #1:** If `n` and `m` are integers then the Python expressions `n//m` and `n%m` will evaluate to the quotient and remainder when `n` is divided by `m`.

**Programming hint #2:** Although it is, in general, a bad idea to use single characters as variable names, you can make an exception for this exercise because it is hard to give sensible names to the variables used in the calculation set out above.

## Example of use
```
Enter the year? 2017
a =  3
b =  20
c =  17
d =  5
e =  0
f =  1
g =  6
h =  21
i =  4
k =  1
l =  4
m =  0
n =  4
p =  15
Easter is on  2017-4-16
```

## Explanation of automated tests

The test data used is shown below

| test| year | month of Easter | day of Easter |
| --- | ---  | ---  | ---  | 
| test_1 | 2017 | 4 | 16 |
| test_2 | 2016 | 3 | 27 |
| test_3 | 2026 | 4 | 5 |
| test_4 | 2005 | 3 | 27 |

The easiest way to pass the automated tests is to produce output of exactly the form illustrated in the example of use. However the tests will pass if the last three unsigned integers found in the output are the year, month, and day of Easter, in that order.
**Note:** It is OK to put spaces around the dashes in the date. For example, if `2005-03-27` passes a test, then so will `2005 - 03 - 27`

