import io
import sys
import re
from contextlib import redirect_stdout

def test1(testCase):
  doTest(testCase,2017,4,16)

def test2(testCase):
  doTest(testCase,2016,3,27)

def test3(testCase):
  doTest(testCase,2026,4,5)

def test4(testCase):
  doTest(testCase,2005,3,27)

def doTest(testCase, year, month, day):
  inputStr = str(year) + '\n'
  outputStr = runMain(inputStr)
  analyseOutput(testCase, inputStr, outputStr, year, month, day)

def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
	  exec(mainfile.read(),{ "__name__":"__main__"})
  mainfile.close()
  return output.getvalue()

def analyseOutput(testCase, inputStr, outputStr, year, month, day):
  outSplit = re.split('\D+',outputStr.strip())
  ints = []
  for word in outSplit:
    if isUnsignedInteger(word):
      ints.append(int(word))

  if len(ints) < 3:
    msg = makeMessage(inputStr, outputStr, year,month,day, "Needed at least three integers in output. Didn't find them!")
    testCase.fail(msg)
  elif ints[-1] != day or ints[-2] != month or ints[-3] != year:
    msg = makeMessage(inputStr, outputStr, year,month,day, "Output is not what was expected")
    testCase.fail(msg)

def makeMessage(inputStr, outputStr, year, month, day, explanation):
  msg = "\n######################################################"
  msg += "\nTest input was:\n"
  msg += inputStr
  msg += "\nOutput was:\n" + outputStr 
  msg += "\nExpected that actual output would tell us that Easter was on " + str(year)+ '-' +str(month) + '-' + str(day)
  msg += "\n" + explanation
  msg += "\n######################################################"
  return msg

def isUnsignedInteger(str):
  regex = '\d+'
  return re.search(regex,str)