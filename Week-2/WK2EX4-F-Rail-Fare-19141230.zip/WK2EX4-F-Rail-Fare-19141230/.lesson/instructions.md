## Instructions

Write a program that asks the user to input their age and outputs a rail fare which is 120 pounds for those aged under 16 or over 59, and 150 pounds otherwise.

## Example of use
```
Enter age: 16
Fare is  150
```
## Explanation of automated tests

The test data used is shown below

| test| age | fare |
| --- | ---  | ---            | 
| test_1 | 15 | 120 |
| test_2 | 16 | 150 |
| test_3 | 59 | 150 | 
| test_4 | 60 | 120 |

The easiest way to pass the automated tests is to produce output of exactly the form illustrated in the examples. However the tests will pass if the last word in the output is as expected (in other words it is `120`, or `150`, according to the age entered). 