import io
import sys
from contextlib import redirect_stdout

def test1(testCase):
  doTest(testCase,15,"120")

def test2(testCase):
  doTest(testCase,16,"150")

def test3(testCase):
  doTest(testCase,59,"150")

def test4(testCase):
  doTest(testCase,60,"120")

def doTest(testCase, age, fare):
  inputStr = str(age) + '\n'
  outputStr = runMain(inputStr)
  analyseOutput(testCase, inputStr, outputStr, fare)

def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
	  exec(mainfile.read(),{ "__name__":"__main__"})
  mainfile.close()
  return output.getvalue()

def analyseOutput(testCase, inputStr, outputStr, fare):
  outSplit  = outputStr.strip().lower().split()
  if len(outSplit) < 1:
    msg = makeMessage(inputStr, outputStr, fare, "Needed at least one word in output. Didn't find one")
    testCase.fail(msg)
  elif outSplit[-1] != fare:
    msg = makeMessage(inputStr, outputStr, fare, "Output is not what was expected")
    testCase.fail(msg)

def makeMessage(inputStr, outputStr, fare, explanation):
  msg = "\n######################################################"
  msg += "\nTest input was:\n"
  msg += inputStr
  msg += "\nOutput was:" + outputStr 
  msg += "\nExpected that actual output would tell us that fare was " + fare
  msg += "\n" + explanation
  msg += "\n######################################################"
  return msg
  