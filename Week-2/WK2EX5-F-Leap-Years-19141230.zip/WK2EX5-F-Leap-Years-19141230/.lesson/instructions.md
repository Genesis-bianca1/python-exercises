## Instructions

In the Gregorian calendar a year with 366 days is called a ‘leap’ year. The others are called ‘common’ years.  Usually years that are divisible by 4 are  leap years (example 2016). However, years that are divisible by 100 but not 400 are common years (example 1900). Years that are divisible by 400 are leap years (example 2000). 
Write a program that allows the user to enter a year, and then says whether this year is a leap year or a common year.

## Example of use #1
```
Enter year: 1985
Common year
```

## Example of use #2
```
Enter year: 1992
Leap year
```

**Important Note:** In order to pass the automated tests, you will need to ensure that the prompt supplied when the user enters the year ends with a space. The prompt `'Enter year: '` will work, but`'Enter year:'` will not.

## Explanation of automated tests

The test data used is shown below

| test| year | leap or common |
| --- | ---  | ---            | 
| test_1 | 1992 | leap |
| test_2 | 1991 | common |
| test_3 | 1900 | common | 
| test_4 | 2000 | leap |

The easiest way to pass the automated tests is to produce output of exactly the form illustrated in the examples. However the tests will pass if the penultimate word in the output is as expected (in other words it is "Leap" for leap years and "Common" for common years). The tests ignore case, so "leap" or "common" would work as well.

