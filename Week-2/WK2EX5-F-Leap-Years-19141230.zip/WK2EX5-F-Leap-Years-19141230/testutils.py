import io
import sys
from contextlib import redirect_stdout

def test1(testCase):
  doTest(testCase, 1992, True)
def test2(testCase):
  doTest(testCase, 1991, False)
def test3(testCase):
  doTest(testCase, 1900, False)
def test4(testCase):
  doTest(testCase, 2000, True)

def doTest(testcase, year, isLeap):
  inputStr = str(year) + '\n'
  outputStr = runMain(inputStr)
  analyseOutput(testcase, inputStr, outputStr, isLeap)

def analyseOutput(testCase, inputStr, outputStr, isLeap):
  outSplit  = outputStr.strip().lower().split()
  #testCase.fail(outSplit)
  if len(outSplit) < 2:
    msg = makeMessage(inputStr, outputStr, isLeap, "Needed two words in output. Didn't find them")
    testCase.fail(msg)
  elif isLeap and outSplit[-2] != "leap" or (not isLeap) and outSplit[-2] != "common":
    msg = makeMessage(inputStr, outputStr, isLeap, "Output is not what was expected")
    testCase.fail(msg)

  
def makeMessage(inputStr, outputStr, isLeap, explanation):
  msg = "\n######################################################"
  msg += "\nTest input was:\n"
  msg += inputStr
  msg += "\nOutput was:" + outputStr 
  msg += "\nExpected that actual output would tell us that this was a "
  if isLeap:
    msg += " leap year"
  else:
    msg += " common year"
  msg += "\n" + explanation
  msg += "\n######################################################"
  return msg

def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  with redirect_stdout(output):
	  exec(open('main.py').read(),{ "__name__":"__main__"})
  return output.getvalue()