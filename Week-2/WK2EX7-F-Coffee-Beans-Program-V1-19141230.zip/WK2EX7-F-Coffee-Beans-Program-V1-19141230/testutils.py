import io
import sys
import re
from contextlib import redirect_stdout

def test1(testCase):
  doTest(testCase,5,6,{"BB","WW","BW"},"BB",4,6)
def test2(testCase):
  doTest(testCase,2,2,{"BB","WW","BW"},"BW",1,2)
def test3(testCase):
  doTest(testCase,2,1,{"BB","BW"},"BB",1,1)
def test4(testCase):
  doTest(testCase,1,2,{"BW","WW"},"WW",2,0)
def test5(testCase):
  doTest(testCase,1,1,{"BW"},"BW",0,1)

def doTest(testCase, initBlack, initWhite, options, optionChosen, finalBlack, finalWhite):
  inputStr = str(initBlack) + '\n' + str(initWhite) + '\n' + optionChosen + '\n'
  outputStr = runMain(inputStr)
  analyseOutput(testCase, inputStr, outputStr, options, finalBlack, finalWhite)

def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
	  exec(mainfile.read(),{ "__name__":"__main__"})
  mainfile.close()
  return output.getvalue()

def analyseOutput(testCase, inputStr, outputStr, options, finalBlack, finalWhite):
  outSplit = re.split('\s+',outputStr.upper())
  ints = []
  optionsPresented = set()
  for word in outSplit:
    if isInteger(word):
      ints.append(int(word))
    if word in {"BB","WW","BW"}:
      optionsPresented.add(word)

  if len(ints) < 2:
    msg = makeMessage(inputStr, outputStr, options, finalBlack, finalWhite, "Needed at least two integers in output. Didn't find them!")
    testCase.fail(msg)
  elif options != optionsPresented:
    msg = makeMessage(inputStr, outputStr, options, finalBlack, finalWhite, "The options presented to the user are not as expected!")
    testCase.fail(msg)
  elif ints[-1] != finalWhite or ints [-2] != finalBlack:
    msg = makeMessage(inputStr, outputStr, options, finalBlack, finalWhite, "The numbers of black and white beans are not expected")
    testCase.fail(msg)

def makeMessage(inputStr, outputStr, options, finalBlack, finalWhite, explanation):
  msg = "\n######################################################"
  msg += "\nTest input was:\n"
  msg += inputStr
  msg += "\nOutput was:\n" + outputStr 
  msg += "\nExpected that actual output would tell us that options  open to user are: "
  for option in options:
    msg += option + ' '
  msg += "(not necessarily in that order)"
  msg += "\nExpected final number of black beans: " + str(finalBlack)
  msg += "\nExpected final number of white beans: " + str(finalWhite)
  msg += "\n" + explanation
  msg += "\n######################################################"
  return msg

def isInteger(str):
  regex = '[-+]?\d+'
  return re.fullmatch(regex,str) != None