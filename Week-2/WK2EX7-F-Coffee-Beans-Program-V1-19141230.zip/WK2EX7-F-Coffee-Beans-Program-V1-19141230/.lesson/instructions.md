# Instructions

Write a program that allows the user to calculate the result of removing two beans from one of coffee cans discussed in last week&#39;s class. The program should work like this:

1. The user is asked to specify the number of white beans, and the number of black beans in the can.
2. The user is then asked to pick one option from a maximum of three. The potential options are:
  - Pick two black beans out of the can (only offer this option if there are two or more black beans in the can).
  - Pick two white beans out of the can (only offer this option if there are two or more white beans in the can).
  - Pick out one black bean and one white bean (only offer this option is there is at least one black bean and at least one white bean in this can).
3. The numbers of black and white beans are then adjusted according to the rules set out in last week&#39;s class. That is to say that
  - If the beans picked out are the same colour then you remove them, and add a black bean.
  - If one black bean and one white bean is picked out then you keep the white bean, and throw away the black one.
4. The new numbers of black and white beans are output.

Note that your program does **not** model the complete sequence of operations required to reduce the number of beans to 1. It just models one step in that sequence. Here are two example runs to illustrate how the program might look to a user.

**Example of use #1**
```
Enter number of black beans in can: 5
Enter number of white beans in can: 6
Allowed operations:
BB pick out two black beans
WW pick out two white beans
BW pick out one white and one black beans
Enter your option: BB
After the operation there are: 
4 black beans
6 white beans
```



**Example of use #2** (Note that we do not offer the option `BB` because there are not enough black beans).
```
Enter number of black beans in can: 1
Enter number of white beans in can: 3
Allowed operations:
WW pick out two white beans
BW pick out one white and one black beans
Enter your option: BW
After the operation there are: 
0 black beans
3 white beans
```


**Hint on development.**

This problem can be approached using iterative development, in other words by solving a series of simplified versions of the problem. Here is a series of programs that you could develop:

**Program 1:** Simply reads in the numbers of black and white beans and prints them out.

**Program 2:** Reads in the numbers of black and white beans and prints out the operations that can be performed. That is to say that it offers the user the options `BB` and/or `WW` and/or `BW` depending on the number of black and white beans.

**Program 3:** Modification of program 2 that calculates the new numbers of black and white beans. This is the complete solution of this exercise.

## Explanation of automated tests

The test data used is shown below

| Test| Initial black,white beans | Expected options for user | Option chosen  |Expected final black, white beans |
| --- | ---  | --- | --- | --- |
| test_1 | 5,6| `BB` `WW` `BW` | `BB` |4,6 |
| test_2 | 2,2| `BB` `WW`,`BW` | `BW` |1,2 |
| test_3 | 2,1| `BB` `BW` | `BB` |1,1 |
| test_4 | 1,2| `BW` `WW` | `WW` |2,0 |
| test_5 | 1,1| `BW` | `BW` |0,1 |


The easiest way to pass the automated tests is to produce output of exactly the form illustrated in the examples of use. However the tests will pass if:
* The input consists of: the initial number of black beans, the initial number of white beans, and the option chosen by the user (either `BB` `WW` or `BW`), in that order.
* The last two integers integers found in the output are the numbers black and white beans, in that order, and
* The output contains all the allowed operations, and none of the operations that are not expected.

**IMPORTANT NOTE:** When you output the allowed operations, you must make sure that their two letter codes are separated from anything else by white space. For example 
```
WW pick out two white beans
```` 
will work, so long as it is on a line by itself, but 
```
WW: pick out two white beans
```
will not work, because of the colon character`:`.