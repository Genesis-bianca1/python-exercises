# Exercise 1:

Write a program that calculates the user's Body Mass Index (BMI). It should ask the user to enter their height and weight as an integer number of kilogrammes, and an integer number of centimetres. The output should be as follows:

- If the user entered a height of zero, the program should output the string `N/A`.
- Otherwise it should output the user's BMI, preceded by the phrase `Your BMI is`. Reminder: BMI is calculated by dividing the weight in kilogrammes by the square of the height **in metres**.

An example run is shown below.

```
Enter your weight (kg)>80
Enter your height (cm)>120
Your BMI is  55.55555555555556
````

## Explanation of automated tests

The test data used is shown below

| Test| Weight| Height | Expected Output |
| --- | ---  | --- |--- |
| test_1 | `80`| `200` | `20` |
| test_2 | `80`| `0` | `N/A` |

The easiest way to pass the automated tests is to produce output of exactly the form illustrated in the examples of use. However the tests will pass if the progam reads in the weight, then the height, in that order and if the output ends with either the BMI (accurate to with 0.01 of correct answer), separated from the rest of the output by a space, or the phrase `N/A`, also separated from the rest of the output by a space.