import io
import sys
from contextlib import redirect_stdout

def test1(testcase):
  inputStr = "80\n200\n"
  outputStr = runMain(inputStr)
  expectedNbr = 20
  outputNbr = extractNumericResult(testcase,inputStr, outputStr)
  if abs(expectedNbr - outputNbr) > 0.01:
    bar = "################EXPLANATION########################"
    msg = bar
    msg += explainInOut(inputStr, outputStr)
    msg += "\nExpected numeric result: " + str(expectedNbr)
    msg += "\nActual numeric result:" + str(outputNbr)
    msg += bar
    testcase.fail(msg)
  

def test2(testcase):
  expectedEnd = "N/A"
  inputStr = "80\n0\n"
  outputStr = runMain(inputStr)
  outStrip = outputStr.strip()
  if not outStrip.endswith(expectedEnd):
    actualEnd = outStrip[-3:]  
    msg = explainInOut(inputStr,outputStr) + '\nOutput ends with: ' + actualEnd + '\nExpected it to end with: ' + expectedEnd
    testcase.fail(msg)


def extractNumericResult(testcase, inputStr, outputStr):
  outputSplit = outputStr.split()
  length = len(outputSplit)
  if length <= 0:
    msg = explainInOut(inputStr, outputStr) + "\nTest failed becuause there was no output"
    testcase.fail(msg)
  else:
    outputNbr = float(outputSplit[length-1].strip())
  return outputNbr


def explainInOut(inputStr, outputStr):
  bar = "################EXPLANATION########################"
  msg = bar
  msg = "\nInput was:\n" + inputStr + "\nOutput was:\n" + outputStr
  msg += bar
  return msg

def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
	  exec(mainfile.read(),{ "__name__":"__main__"})
  mainfile.close()
  return output.getvalue()