## Instructions

Write a program that allows the user to enter four integers representing the start times and durations of two events (as whole hours) and then tells the user whether those events overlap. You may assume that the two events start on the hour, that they last an integer number of hours, and that they both take place on the same calendar day. The final output should be either `Events overlap` or `Events do not overlap`. 

Clarification: If one event starts at exactly the same time as the other ends, then they should **not** be considered to overlap.

In order to pass the automated tests, the input must be four integers representing the start hour of event A (as an integer in the range 0-23), the duration of event A (In hours), and then the start hour of event B and the duration of event B in the same format. You should **not** assume that event A starts before event B.

**Hint:** it may be easier to think about the circumstances where the meetings do _not_ overlap.

### Example Run #1
```
Enter start hour for event A:13
Enter duration of event A (in hours):2
Enter start hour for event B:9
Enter duration of event B (in hours):4
Events do not overlap
```
### Example Run #2
```
Enter start hour for event A:10
Enter duration of event A (in hours):2
Enter start hour for event B:11
Enter duration of event B (in hours):1
Events overlap
```

## Explanation of automated tests

The test data used is shown below. The integers used as input are the start hour of event A, the duration of event A, the start hour of event B, and the duration of event B, in that order.

| Test| Integers Used as Input | overlap or not overlap|
| --- | ---  | --- |
| test_1 | `13`, `2`, `15`, `3`| `not overlap`|
| test_2 | `9`, `4`, `14`, `1`| `not noverlap`|
| test_3 | `12`, `4`,`7`, `5` | `not overlap`|
| test_4 | `11`, `1`, `8`, `2` | `not overlap`|
| test_5 | `9`, `5`, `10`, `6` | `overlap`|
| test_6 | `7`, `7`, `9`, `2` | `overlap`|
| test_7 | `5`, `6`, `10`, `1` | `overlap`|
| test_8 | `7`, `8`, `6`, `5` | `overlap`|
| test_9 | `8`, `9`, `9`, `3` | `overlap`|
| test_10 | `14`, `4`, `10`, `8` | `overlap`|



The easiest way to pass the automated tests is to produce output of exactly the form illustrated in the examples runs above. However the tests will pass if the output ends with `overlap` or 'not overlap` as specified in the table above.