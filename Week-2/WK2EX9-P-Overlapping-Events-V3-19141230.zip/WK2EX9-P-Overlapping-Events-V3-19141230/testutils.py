import io
import sys
from contextlib import redirect_stdout

def doTest(testCase, startA, durA, startB, durB, overlap):
    inputStr = ""
    for num in [startA, durA, startB, durB]:
        inputStr += str(num) + '\n'
    outputStr = runMain(inputStr)
    analyseOutput(testCase, inputStr, overlap, outputStr)


def test1(testCase):
    doTest(testCase, 13, 2, 15, 3, False)

def test2(testCase):
    doTest(testCase, 9, 4, 14, 1, False)

def test3(testCase):
    doTest(testCase, 12, 4, 7, 5, False)

def test4(testCase):
    doTest(testCase, 11, 1, 8, 2, False)

def test5(testCase):
    doTest(testCase, 9, 5, 10, 6, True)

def test6(testCase):
    doTest(testCase, 7, 7, 9, 2, True)

def test7(testCase):
    doTest(testCase, 5, 6, 10, 1, True)

def test8(testCase):
    doTest(testCase, 7, 8, 6, 5, True)

def test9(testCase):
    doTest(testCase, 8, 9, 9, 3, True)
  
def test10(testCase):
    doTest(testCase, 14, 4, 10, 8, True)

def runMain(inputStr):
    output = io.StringIO()
    sys.stdin = io.StringIO(inputStr)
    mainfile = open('main.py')
    with redirect_stdout(output):
        exec(mainfile.read(), {"__name__": "__main__"})
    mainfile.close()
    return output.getvalue()


def analyseOutput(testCase, inputStr, expectedResult, outputStr):
    outStrip = outputStr.strip()
    if not outStrip.endswith("overlap"):
        message = makeExplanation(inputStr, expectedResult, outputStr)
        testCase.fail(message)
    else:
        actualResult = not outputStr.strip().endswith("not overlap")
        if expectedResult != actualResult:
            message = makeExplanation(inputStr, expectedResult, outputStr)
            testCase.fail(message)


def makeExplanation(inputStr, expectedResult, outputStr):
    bar = "\n#####################EXPLANATION#####################\n"
    msg = bar + "Test input was:\n"
    msg += inputStr
    msg += "\nActual output:" + outputStr
    msg += "\nExpected that actual output would say that events "
    if expectedResult:
        msg += "overlap"
    else:
        msg += "do not overlap"
    msg += bar
    return msg
