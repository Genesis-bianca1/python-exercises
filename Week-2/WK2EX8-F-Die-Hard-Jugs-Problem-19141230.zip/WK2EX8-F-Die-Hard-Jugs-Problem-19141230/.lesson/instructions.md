## Instructions

**Note:** This is not a programming exercise and you are not required to submit anything. The problem set out in this exercise will be revisited in future exercises (and those future exercises will require programming).

Suppose that you have been given a 5-litre jug, a 3-litre jug and access to a tap, and you have been asked to measure out exactly four litres. The snag is that neither of the jugs have any measuring marks on them. How do you do that?

In addition, try to answer the following questions

- Is there more than one way of getting 3 litres?
- What if you wanted to measure out 1, or 2, litres?
- Can you think of a good way of representing the problem that will make solutions easy to spot?
- What happens if you are given a 2-litre jug, and a 4-litre jug, and asked to measure out 3 litres?

**Hint:** This is a problem faced by Samuel L Jackson and Bruce Willis in the movie Die Hard 3. Hence there is a lot of discussion of it on the internet, some of which may be useful to you (this is not a portfolio exercise, so you are free to use the internet as you see fit).