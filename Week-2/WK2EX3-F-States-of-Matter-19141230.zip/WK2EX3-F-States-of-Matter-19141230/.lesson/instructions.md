## Instructions

Write a program that asks the user to input a temperature in Celsius (as a number that can include a decimal point) and then tells user whether water is liquid solid or gaseous at that temperature at sea level.

__Physics Reminder__
Water is solidifies at 0 Celsius and boils at 100 Celsius.

## Example of use
```
Enter temperature in Celsius > -4.5
Water is solid
```

## Explanation of automated tests

The test data used is shown below

| test| temperature | state |
| --- | ---  | ---            | 
| test_1 | -0.01 | "solid" |
| test_2 | 0.01 | "liquid" |
| test_3 | 99.99 | "liquid" | 
| test_4 | 100.01 | "gaseous" |

The easiest way to pass the automated tests is to produce output of exactly the form illustrated in the examples. However the tests will pass if the last word in the output is as expected (in other words it is "solid", "liquid", or "gaseous", according to temperature). The tests ignore case, so "Liquid" works as well as "liquid".


