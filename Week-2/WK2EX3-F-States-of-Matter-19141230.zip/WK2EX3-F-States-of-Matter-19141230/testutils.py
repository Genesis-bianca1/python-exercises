import io
import sys
from contextlib import redirect_stdout

def test1(testCase):
  doTest(testCase, -0.01,"solid")

def test2(testCase):
  doTest(testCase, 0.01,"liquid")

def test3(testCase):
  doTest(testCase, 99.99,"liquid")

def test4(testCase):
  doTest(testCase, 100.01,"gaseous")

def doTest(testCase, temp, state):
  inputStr = str(temp) + '\n'
  outputStr = runMain(inputStr)
  analyseOutput(testCase, inputStr, outputStr, state)

def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  with redirect_stdout(output):
	  exec(open('main.py').read(),{ "__name__":"__main__"})
  return output.getvalue()

def analyseOutput(testCase, inputStr, outputStr, state):
  outSplit  = outputStr.strip().lower().split()
  if len(outSplit) < 1:
    msg = makeMessage(inputStr, outputStr, state, "Needed at least one word in output. Didn't find it")
    testCase.fail(msg)
  elif outSplit[-1] != state:
    msg = makeMessage(inputStr, outputStr, state, "Output is not what was expected")
    testCase.fail(msg)

def makeMessage(inputStr, outputStr, state, explanation):
  msg = "\n######################################################"
  msg += "\nTest input was:\n"
  msg += inputStr
  msg += "\nOutput was:" + outputStr 
  msg += "\nExpected that output would tell us that water was " + state
  msg += "\n" + explanation
  msg += "\n######################################################"
  return msg