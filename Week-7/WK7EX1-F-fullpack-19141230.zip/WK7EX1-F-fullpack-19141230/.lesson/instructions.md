## Instructions  
**Note:** You should attempt to complete this exercise without introducing any `import` statements into your code.

**Note:** There are no automated tests for this exercise.

Unicode characters for the suits in a pack of cards can be represented in Python as `'♥'`, `'♠'`, `'♣'`, and `'♦'` or, if you want something that you can type at a terminal, as `'\u2660'`,`'\u2665'`,`'\u2666'`, and `'\u2663'`.  This is illustrated by the code below, which you could run in the console (similar code can be found in the main.py file).
```
> for suit in {'\u2660','\u2665','\u2666','\u2663'}:
	print(suit)
	
♥
♠
♣
♦
```

Using the above characters, write a function `fullpack` that takes no parameters and returns a set representing a full pack of cards (no jokers), as illustrated by the example of use below. You should use loops to reduce the amount of code written (so don't explicitly write out 52 separate character strings).

## Example of Use 
```
> pack = fullpack()
> print(pack)
{'♥10', '♦3', '♣4', '♠K', '♣J', '♥7', '♦8', '♦9', '♦7', '♣2', '♥J', '♠A', '♠9', '♠4', '♣10', '♠7', '♦A', '♥3', '♣9', '♠J', '♠10', '♠Q', '♥6', '♠3', '♣7', '♣K', '♥Q', '♣6', '♦2', '♦5', '♥4', '♠2', '♣5', '♠8', '♥5', '♦4', '♥2', '♥A', '♥8', '♦10', '♣A', '♦K', '♣8', '♣Q', '♥K', '♠5', '♦Q', '♠6', '♥9', '♦6', '♦J', '♣3'}
```

  