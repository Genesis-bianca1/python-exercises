# Returns stats of competitors FROM a specific TIME RANGE
def get_interval_data(start_secs, end_secs, results):
  # Entrants in the list results whose time (in seconds)
  count = 0
  seconds_sum = 0

  for competitor in results:
    competitor_time = get_secs(competitor['time'])

    if start_secs <= competitor_time <= end_secs:
      count += 1
      seconds_sum += competitor_time

  mean = seconds_sum / count if count > 0 else 0

  return {'count':count, 'mean':mean} 



# 'I' USER to DEFINE RANGE of TIMES: Shows competitor's STATISTICS WITHIN that SPECIFIED-RANGE
def display_nbr_in_interval(results):
    start_time = input('Enter start time of interval (hh:mm:ss): ')
    start_secs = get_secs(start_time)
    end_time = input('Enter end time of interval (hh:mm:ss): ')
    end_secs = get_secs(end_time)
    interval_data = get_interval_data(start_secs, end_secs, results)
    print('Number of competitors finishing in this interval = ', interval_data['count'])
    if interval_data['count'] != 0:
        secs = interval_data['mean']
        mins = secs//60
        secs = secs%60
        hours = mins//60
        mins = mins%60
        print('Mean time in interval is ',int(hours),'hours',int(mins),'minutes','and ',int(secs),'seconds')
    else:
        print('No competitors in interval')

def get_secs(time):
    time_split = time.split(':')
    seconds = int(time_split[2]) + 60*int(time_split[1]) + 60*60*int(time_split[0])
    return seconds