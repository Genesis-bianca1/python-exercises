## Instructions

The Replit project for this exercise contains a file `marathon.txt` . This file contains data about a half marathon race. This consists of lines containing comma-separated data, like this

```
3070,01:44:03,Aaron,Glue,Finished  
480,02:06:47,Aaron,Collins,Finished  
2228,01:42:06,Abigail,Swales,Finished  
1519,01:24:11,Adam,Mcarthur,Finished  
651,01:28:14,Adam,Dent,Finished  
1322,01:28:31,Adam,King,Finished  
```


Each line in the file has four components separated by commas. These are: the id (race number) of the competitor; the time they took to complete the race, in the form `hh:mm:ss` their first name; their second name, and a &#39;status&#39; which always has the value `Finished` (we won't be making any use of the status).

The project also contains a file `marathon10.txt` that contains just the first ten lines of `marathon.txt`. If you want to write some experimental code (which I would strongly advise you to do) then you may find that `marathon10.txt` is useful for testing. **N.B. marathon10.txt is used by the automated tests**

The file `main.py` contains a program that, if completed, would allow us to display information read from the file marathon.txt. If you run the program, and then type
```
main()
```
at the console, you should start a program running that looks like this
```
Options are:
S - Show data for a competitor
I - Show statistics for competitors finishing in a given interval
Q - Quit the program
Select option:
```
The intention is that typing `S` will result in the user being asked to specify a competitor's race number and then being shown information about that competitor, and that typing `I` will result in the user being asked to define a range of times and then being shown statistics about competitors whose finish times lie in that range.

However the program does not work yet, because there are two functions `read_file` and `get_interval_data` that have not been completely implemented. You will implement `read_file` in Exercise 1, and `get_interval_data` in Exercise 2.

**Note #1:** You should **only** modify the functions `read_file` and `get_interval_data`. You should not modify any other code and you should not introduce any global variables. If you modify other functions you will probably find that the automated tests fail.

**Note #2** You should implement the function `read_file` so that it will read any file in the correct format, not just the files supplied with this exercise.

**Note #3:** Your code should not contain the keywords `break`, `continue`, or `pass`. The reasons for avoiding those keywords have been set out in the lectures.

**Note #4:** You should complete this exercise without introducing any `import` statements into your code.

## Exercise 10 [P]

The function `read_file` takes a filename as a parameter. At the moment it just returns an empty list. However, it is meant to return a list of dictionaries, where each dictionary has keys that define data about an individual competitor in the file. The keys for the dictionaries are `'id'`, `'time'`, `'firstname'`, and `'lastname'`, whose use is, I hope obvious. You do not need to pay any attention to the last entry in each line (the one that reads `Finished`). Once you have completed this exercise, you should find that the function behaves as illustrated below.

```
>results = read_file('marathon10.txt')
>print(results)
[{'id': '3070', 'time': '01:44:03', 'firstname': 'Aaron', 'lastname': 'Glue'}, {'id': '480', 'time': '02:06:47', 'firstname': 'Aaron', 'lastname': 'Collins'}, {'id': '2228', 'time': '01:42:06', 'firstname': 'Abigail', 'lastname': 'Swales'}, {'id': '1519', 'time': '01:24:11', 'firstname': 'Adam', 'lastname': 'Mcarthur'}, {'id': '651', 'time': '01:28:14', 'firstname': 'Adam', 'lastname': 'Dent'}, {'id': '1322', 'time': '01:28:31', 'firstname': 'Adam', 'lastname': 'King'}, {'id': '2398', 'time': '01:37:19', 'firstname': 'Adam', 'lastname': 'Walker'}, {'id': '427', 'time': '01:38:30', 'firstname': 'Adam', 'lastname': 'Clark'}, {'id': '698', 'time': '01:38:39', 'firstname': 'Adam', 'lastname': 'Drury'}, {'id': '2182', 'time': '01:40:44', 'firstname': 'Adam', 'lastname': 'Stainton'}]
```

Complete the implementation of read_file so that it behaves correctly.

If you do this, and then run the function `main()` you should now find that option S now works. This is illustrated below
```
>main()
Options are:
S - Show data for a competitor
I - Show statistics for competitors finishing in a given interval
Q - Quit the program
Select option: 
Enter competitor ID:87
ID : 87
First Name : Adam
First Name : Avenant
Options are:
S - Show data for a competitor
I - Show statistics for competitors finishing in a given interval
Q - Quit the program
Select option:
```

**N.B.** As mentioned in the introduction, you should **only** modify the function `read_file`, and this function should work with any file in the correct format, not just the two files supplied with this exercise.

## Exercise 11 [P]

The function `get_interval_data` is meant to return statistics for the competitors whose times lie in a given range. Its parameters are

`start_secs` – the shortest time in the range (in seconds)

`end_secs` – the longest time in the range (in seconds)

`results` – a list of dictionaries in the form returned by `read_file`

The function currently returns the dictionary `{'count':0,'mean':0}`but it should return a dictionary with two keys `'count'` and `'mean'` which are associated with the total number of competitors whose times lie in the specified range (inclusive) and the average time that those competitors took to complete the marathon (in seconds). An example call is illustrated below

```
>results = read_file('marathon.txt')
>data = get_interval_data(7200,10800,results)
>print(data)
{'count': 1146, 'mean': 8122.1762652705065}
```

We interpret this as meaning that there were 1146 competitors whose times lay in the range 7200 to 10800 seconds (2-3 hours) inclusive, and that the average time those competitors took to complete the race was 8122.176 seconds.

If the function is working correctly then you will be able to use option `I` in the marathon.py program, as illustrated below.

```
>main()
Options are:
S - Show data for a competitor
I - Show statistics for competitors finishing in a given interval
Q - Quit the program
Select option: I
Enter start time of interval (hh:mm:ss): 02:00:00
Enter end time of interval (hh:mm:ss): 03:00:00
Number of competitors finishing in this interval = 1146
Mean time in interval is 2 hours 15 minutes and 22 seconds
```

Note that when using the program, we enter the times as strings in the form `hh:mm:ss`. The program uses a function `get_secs` to convert that string to a number of seconds.

N.B. You can, and probably should, use the function `get_secs` when implementing `get_interval_data`.

**N.B.** As mentioned in the introduction, you should **only** modify the function `get_interval_data`. You should not modify any other code and you should not introduce any global variables.

## Explanation of Automated Tests 

There are four automated tests.

**test_1:** Makes the following function call:
```
read_file('marathon10.txt')
```
Then checks that the results are as expected. The results should be

```
[{'id': '3070', 'time': '01:44:03', 'firstname': 'Aaron', 'lastname': 'Glue'}, {'id': '480', 'time': '02:06:47', 'firstname': 'Aaron', 'lastname': 'Collins'}, {'id': '2228', 'time': '01:42:06', 'firstname': 'Abigail', 'lastname': 'Swales'}, {'id': '1519', 'time': '01:24:11', 'firstname': 'Adam', 'lastname': 'Mcarthur'}, {'id': '651', 'time': '01:28:14', 'firstname': 'Adam', 'lastname': 'Dent'}, {'id': '1322', 'time': '01:28:31', 'firstname': 'Adam', 'lastname': 'King'}, {'id': '2398', 'time': '01:37:19', 'firstname': 'Adam', 'lastname': 'Walker'}, {'id': '427', 'time': '01:38:30', 'firstname': 'Adam', 'lastname': 'Clark'}, {'id': '698', 'time': '01:38:39', 'firstname': 'Adam', 'lastname': 'Drury'}, {'id': '2182', 'time': '01:40:44', 'firstname': 'Adam', 'lastname': 'Stainton'}]
```

**test_2:**: Assigns a value to a variable `results` as follows:
```
results = [{'id': '3070', 'time': '01:44:03', 'firstname': 'Aaron', 'lastname': 'Glue'}, {'id': '480', 'time': '02:06:47', 'firstname': 'Aaron', 'lastname': 'Collins'}, {'id': '2228', 'time': '01:42:06', 'firstname': 'Abigail', 'lastname': 'Swales'}, {'id': '1519', 'time': '01:24:11', 'firstname': 'Adam', 'lastname': 'Mcarthur'}, {'id': '651', 'time': '01:28:14', 'firstname': 'Adam', 'lastname': 'Dent'}, {'id': '1322', 'time': '01:28:31', 'firstname': 'Adam', 'lastname': 'King'}, {'id': '2398', 'time': '01:37:19', 'firstname': 'Adam', 'lastname': 'Walker'}, {'id': '427', 'time': '01:38:30', 'firstname': 'Adam', 'lastname': 'Clark'}, {'id': '698', 'time': '01:38:39', 'firstname': 'Adam', 'lastname': 'Drury'}, {'id': '2182', 'time': '01:40:44', 'firstname': 'Adam', 'lastname': 'Stainton'}]
```

Then calls `get_interval_data(5400,7200,results)` and checks that the results are as expected. The return value should be
```
{'count':6,'mean':6013.5}
```
**test_3:** Checks that you have completed the exercise without using the keywords `break`, `continue`,  `pass`, or `import`.

**test_4:** Checks that the string `marathon10.txt` does not appear in your code, and that the only occurrence of the string `marathon.txt` is the one that already appears on line 2 . The two functions that you have written should work with any file that is in the correct format, not just the files that were provided for test purposes.