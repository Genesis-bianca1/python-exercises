from main import read_file,get_interval_data
import re

def getList():
  return [{'id': '3070', 'time': '01:44:03', 'firstname': 'Aaron', 'lastname': 'Glue'}, {'id': '480', 'time': '02:06:47', 'firstname': 'Aaron', 'lastname': 'Collins'}, {'id': '2228', 'time': '01:42:06', 'firstname': 'Abigail', 'lastname': 'Swales'}, {'id': '1519', 'time': '01:24:11', 'firstname': 'Adam', 'lastname': 'Mcarthur'}, {'id': '651', 'time': '01:28:14', 'firstname': 'Adam', 'lastname': 'Dent'}, {'id': '1322', 'time': '01:28:31', 'firstname': 'Adam', 'lastname': 'King'}, {'id': '2398', 'time': '01:37:19', 'firstname': 'Adam', 'lastname': 'Walker'}, {'id': '427', 'time': '01:38:30', 'firstname': 'Adam', 'lastname': 'Clark'}, {'id': '698', 'time': '01:38:39', 'firstname': 'Adam', 'lastname': 'Drury'}, {'id': '2182', 'time': '01:40:44', 'firstname': 'Adam', 'lastname': 'Stainton'}]

def test1(testcase):
  expected = getList()
  actual = read_file('marathon10.txt')
  if (expected != actual):
    explanation = "Actual and expected values do not match"
    actual = read_file('marathon10.txt')
    functionCall =  "read_file('marathon10.txt')"
    msg = makeMessage(functionCall,expected,actual,explanation)
    testcase.fail(msg)

def test2(testcase):
  results = getList()
  expected = {'count':6,'mean':6013.5}
  actual = get_interval_data(5400,7200,results)
  if not closeEnough(expected,actual):
    explanation = "Actual and expected values do not match"
    functionCall = "get_interval_data(5400,7200,results)"
    functionCall += "\nWith results taking the value: " + str(results)
    msg = makeMessage(functionCall,expected,actual,explanation)
    testcase.fail(msg)

def test3(testCase):
  mainfile = open('main.py')
  programText = mainfile.read()
  mainfile.close()
  progSplit =re.split('\W+',programText)
  forbidden = ['break', 'continue', 'pass', 'import']
  badWords = [word for word in progSplit if word in forbidden]
  if len(badWords) >= 1:
    bar = '\n##################EXPLANATION###################\n'
    msg = bar + "The following keywords have been used in your code: " + wordListString(badWords) + "\n"
    msg += "You should try to code without using the keywords: " + wordListString(forbidden) + bar
    testCase.fail(msg)

def test4(testCase):
  mainfile = open('main.py')
  programText = mainfile.read()
  mainfile.close()
  progSplit =re.split('[^a-zA-Z0-9_\.]',programText)
  forbidden = ['marathon.txt', 'marathon10.txt']
  badWords = [word for word in progSplit if word in forbidden]
  if len(badWords) >= 2:
    bar = '\n##################EXPLANATION###################\n'
    msg = bar + "The following strings have been used in your code: " + wordListString(badWords) + "\n"
    msg += "It looks as if you have been making assumptions about file names!" + bar
    testCase.fail(msg)

def wordListString(wordList):
  result = ""
  for word in wordList:
    result += word + ' '
  return result

def closeEnough(expected,actual):
  return isinstance(actual,dict) and expected.keys() == actual.keys() and expected['count'] == actual['count'] and abs(expected['mean'] - actual['mean'] < 0.05)

def makeMessage(functionCall,expected,actual,explanation):
  bar ="\n###########EXPLANATION#############\n"
  msg = bar + "Function call: " + functionCall
  msg += "\nExpected return value: " + str(expected)
  msg += "\nActual return value: " + str(actual)
  msg += "\n" + explanation + bar
  return msg