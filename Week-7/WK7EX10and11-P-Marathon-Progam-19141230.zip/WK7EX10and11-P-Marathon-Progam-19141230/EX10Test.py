def read_file(filename):
  myfile = open(filename)
  readlines = myfile.readlines()
  results = []

  for line in readlines:
    element = line.split(',')
    id = element[0]
    time = element[1]
    firstname = element[2]
    lastname = element[3]
    results.append({'id': id, 'time': time, 'firstname': firstname, 'lastname': lastname})

  myfile.close()
  return results