from main import deal

def test1(testcase):
  handSize = 5
  pack = {'♣9', '♦K', '♥A', '♥5', '♣3', '♠4', '♦6', '♦A', '♦1', '♦2', '♦9', '♣J'}
  originalPack = pack.copy()
  hand = deal(pack,handSize)
  if not(isinstance(hand,set)):
    explanation = 'The call to deal did not return a set'
    msg = makeMessage(handSize,hand,originalPack, pack, explanation)
    testcase.fail(msg)
  size = len(hand)
  if not(size == handSize):
    explanation = 'Expected deal to return a set of size ' + str(handSize) + ' actual size was ' + str(size)
    msg = makeMessage(handSize, hand,originalPack,pack, explanation)
    testcase.fail(msg)

def test2(testcase):
  pack = {'♣9', '♦K', '♥A', '♥5', '♣3', '♠4', '♦6', '♦A', '♦1', '♦2', '♦9', '♣J'}
  originalPack = pack.copy()
  handSize = 5
  hand = deal(pack,handSize)
  for card in hand:
    if card in pack:
      explanation = "Card " + card + " is in hand but has not been removed from pack"
      msg = makeMessage(handSize,hand,originalPack,pack,explanation)
      testcase.fail(msg)
    if card not in originalPack:
      explanation = "Card " + card + " is in hand but was not in original pack"
      msg = makeMessage(handSize,hand,originalPack, pack,explanation)
      testcase.fail(msg)
  
def test3(testcase):
  originalPack = {'♥9', '♦2', '♥7', '♣9', '♦1', '♣J', '♣7', '♠3', '♥J', '♣2', '♦J', '♦8', '♣1', '♥2', '♠9', '♠7', '♣3', '♠2', '♠Q', '♣Q', '♦A', '♦3', '♥Q', '♦K', '♠1', '♠5', '♦5', '♦6', '♥3', '♦4'}
  handSize = len(originalPack)//2
  packV1 = originalPack.copy()
  packV2 = originalPack.copy()
  hand1 = deal(packV1,handSize)
  hand2 = deal(packV2,handSize)
  if hand1 == hand2:
    explanation = "Repeating the deal produced exactly the same hand. This is very unlikely to happen by chance"
    msg = makeMessage(handSize,hand1,originalPack,packV1,explanation)
    testcase.fail(msg)

def makeMessage(handSize,hand,originalPack,pack,explanation):
  bar ="\n##############EXPLANATION################\n"
  msg = bar
  msg += "Original pack: " + str(originalPack)
  msg += "\nValue returned by deal(" + str(handSize) + "): " + str(hand)
  msg += "\nPack after deal: "+ str(pack)
  msg += "\n" + explanation + bar
  return msg
