# Instructions  
**Note:** Your code should include the statement `import random`. You should not make use of any other `import` statements.

**NOTE:** You may wish to copy your `fullpack` function from the previous exercise into this project.

Write a function with the following first line

```
def deal(pack,nbr_cards)
```
The parameter `pack` is a set of cards (such as that returned by `fullpack`) and `nbr_cards` is an integer. The function should return a **set** containing `nbr_cards` elements drawn at random from `pack`. These elements should be **removed** from `pack`.

**Hint #1:**
If you import the `random` module into your code, you can use the function `random.sample` which works as follows:

If `coll` is a list or set and `n` is an integer, then `random.sample(coll,n)` returns a list containing `n` values chosen at random from `coll`. The elements of the returned list are non-identical. The elements of the returned list are **not** removed from `coll`. The code below illustrates how the function might be used in the console.

```
> import random
> set1 = {'q','w','e','r','t','y'}
> list2 = random.sample(set1,3)
> print(list2)
['e', 'y', 't']
> print(set1)
{'e', 'r', 't', 'q', 'w', 'y'}
```
**N.B.** The function `random.sample` will be useful when writing your  `deal` function. But you should bear in mind that `random.sample` returns a list whereas `deal` should a set and that `deal` must **remove** elements from the set that is passed to it as an argument, which `random.sample` does not do:

**Hint #1 (Added 7 Nov):**
A list can be converted to a set using the `set` function in the manner illustrated below
```
> mylist = ['q','w','e']
> myset = set(mylist)
> myset
{'q', 'w', 'e'}
```


## Example of Use 
Here is how the `deal` function might be called in the console. Notice how the size of the pack decreases.

```
> pack = fullpack()
> len(pack)
52
> hand = deal(pack,5)
> print(hand)
{'♦Q', '♠7', '♠Q', '♠8', '♣K'}
> len(pack)
47
```

## Explanation of Automated Tests
There are three Tests
* **test_1** calls `deal` to deal a hand of 5 cards from a pack containing 12 and checks that the return value is a set of 5 objects

* **test_2** calls `deal` to deal a hand of 5 cards from a pack containing 12 and checks that the every card in the hand was in the original pack, and is not in the pack that is left after the deal completed.

* **test_3** calls `deal` to deal a hand of 15 cards from a pack containing 30. Then repeats the process, i.e. it deals another hand of 15 from the same 30 card pack. It then checks that the two hands are different. **Note:** It is theoretically possible for this test to fail purely by chance, but the probability of that happening is less than 1 in 150 million.
