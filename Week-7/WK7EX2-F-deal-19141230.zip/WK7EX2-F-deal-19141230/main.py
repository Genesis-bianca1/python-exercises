import random

def fullpack():
  return("Copy your fullpack code here")

def deal(pack,nbr_cards):
  return "Replace me with correct code"

if __name__ == "__main__":
  print("EXAMPLE OF USE (ASSUMES fullpack IS DEFINED)")
  print("A CALL TO deal(fullpack(),5) returns:")
  print(deal(fullpack(),5))