## Instructions  

The file main.py contains a skeleton for a class `Greeter`. The constructor of the class should take a string parameter which is the name of a person to be greeted. The method `get_greeting` should return a greeting consisting of the word `Hello` followed by a space, followed by the name of the person.

Your task is to complete `__init__` and `get_greeting` methods.

## Example of Use
```
> greet = Greeter('David')
> greeting = greet.get_greeting()
> print(greeting)
Hello David
```
## Explanation of Automated Tests
There is one automated test. It performs the following operation five times:
* Create a `Greeter` object for a randomly chosen name
* Call the `get_greeting` method on this object and check that this returns a string consisting of the word `Hello`, followed by a space, followed by the name used.
  
  