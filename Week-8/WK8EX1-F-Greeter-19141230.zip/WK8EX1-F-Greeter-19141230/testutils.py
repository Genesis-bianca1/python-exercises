from main import Greeter
import random

def test1(testCase):
  NUM_TESTS = 5
  SALUTE = 'Hello'
  for i in range(NUM_TESTS):
    name = getRandomName()
    greeter = Greeter(name)
    greeting = greeter.get_greeting()
    split = greeting.split()
    if len(split) != 2 or split[0] != SALUTE or split[1] != name:
      msg = makeMessage(greeting,SALUTE,name)
      testCase.fail(msg)
      
def makeMessage(greeting,salute,name):
  bar = "\n\n###########EXPLANATION###########\n\n"
  msg = bar
  msg += "Constructor call: Greeter(" + name + ")"
  msg += "\nExpected return from get_greeting():" + salute + " " + name
  msg += "\nActual return from get_greeting():" + greeting
  msg += "\nActual return is different from expected return"
  msg += bar
  return msg
  
def getRandomName():
  CODE_A = 65
  CODE_Z = 90
  CODE_a = 97
  CODE_z = 122

  name = chr(random.randint(CODE_A,CODE_Z))
  numChars = random.randint(5,11)
  for i in range(numChars-1):
    name += chr(random.randint(CODE_a,CODE_z))
  return name
  