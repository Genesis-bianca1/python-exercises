class Greeter:

  def __init__(self, name):
    self.name = name

  def get_greeting(self):
    return "Hello" + " " + self.name