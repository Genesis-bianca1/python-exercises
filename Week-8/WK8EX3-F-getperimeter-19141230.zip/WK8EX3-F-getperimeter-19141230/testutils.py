#IMPORTANT: DO NOT CHANGE THIS FILE!
from main import Circle,Rectangle

def test1(testCase):
  doRectanglePerimeterTest(testCase,0,0,1,2,6)

def test2(testCase):
  doRectanglePerimeterTest(testCase,-1,3,5,4,18)

def test3(testCase):
  doCirclePerimeterTest(testCase,0,0,3,18.84955592153)

def test4(testCase):
  doCirclePerimeterTest(testCase,-3,-5,5,31.4159265)

def doRectanglePerimeterTest(testCase,xcen,ycen,width,height,expectedPerimeter):
  rec = Rectangle(xcen,ycen,width,height)
  actualPerimeter = rec.get_perimeter()
  if actualPerimeter != expectedPerimeter:
    msg = makeRecMessage(xcen,ycen,width,height,expectedPerimeter, actualPerimeter)
    testCase.fail(msg)

def doCirclePerimeterTest(testCase,xcen,ycen,radius,expectedPerimeter):
  TOLERANCE = 0.01
  circ = Circle(xcen,ycen,radius)
  actualPerimeter = circ.get_perimeter()
  if abs(actualPerimeter -expectedPerimeter) > TOLERANCE:
    msg = makeCircMessage(xcen,ycen,radius,expectedPerimeter, actualPerimeter)
    testCase.fail(msg)

def makeRecMessage(xcen,ycen,width,height,expectedPerimeter, actualPerimeter):
  bar ="\n##################################\n"
  msg = bar + "Expected Result not seen\n\n"
  msg += "Created Rectangle with\n"
  msg += "xcen" + repr(xcen) + "\n"
  msg += "ycen" + repr(ycen) + "\n"
  msg += "width" + repr(width) + "\n"
  msg += "height" + repr(height) + "\n\n"
  msg += "expected return from get_perimeter: " + repr(expectedPerimeter) + "\n"
  msg += "actual return from get_perimeter: " + repr(actualPerimeter) + "\n"
  return msg

def makeCircMessage(xcen,ycen,radius,expectedPerimeter, actualPerimeter):
  bar ="\n##################################\n"
  msg = bar + "Expected Result not seen\n\n"
  msg += "Created Circle with\n"
  msg += "xcen" + repr(xcen) + "\n"
  msg += "ycen" + repr(ycen) + "\n"
  msg += "radius" + repr(radius) + "\n"
  msg += "expected return from get_perimeter: " + repr(expectedPerimeter) + "\n"
  msg += "actual return from get_perimeter: " + repr(actualPerimeter) + "\n"
  return msg