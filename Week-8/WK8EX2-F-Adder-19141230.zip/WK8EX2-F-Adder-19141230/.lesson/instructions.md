## Instructions  

The file main.py is intentionally empty. Within that file you must write code for a class `Adder` that maintains a running total of numbers. The `__init__` method of the class should take just the `self` argument. There must be two other methods.

`add` takes a number as a parameter and adds it to the running total being maintained.

`get_total` returns the current value of the running total.

## Example of Use
```
> adder = Adder()
> total = adder.get_total()
> print(total)
0
> adder.add(2)
> adder.add(3)
> total = adder.get_total()
> print(total)
5
> adder.add(-1)
> adder.add(2)
> total = adder.get_total()
> print(total)
6
```
## Explanation of Automated Tests
There are three automated tests. Each one creates an `Adder` object and then makes a series of calls to `add` and `get_total` and checks that the return values from `get_total` are correct.

**test_1**

Sequence of calls:
```
adder = Adder()
adder.add(2)
adder.add(-1)
adder.add(3)
adder.get_total()
```
Expects that final call to `get_total` will return 4.

**test_2**

Sequence of calls:
```
adder = Adder()
adder.add(-2)
adder.add(1)
adder.add(3)
adder.get_total()
adder.add(5)
adder.add(-10)
adder.get_total()
adder.add(11)
adder.get_total()
adder.get_total()
```
Expects that the four calls to `get_total` will return 2, -3, 8, and 8 in that order.

**test_3**

Sequence of calls:
```
adder = Adder()
adder.get_total()
```
Expects that call to `get_total` will return 0.
  