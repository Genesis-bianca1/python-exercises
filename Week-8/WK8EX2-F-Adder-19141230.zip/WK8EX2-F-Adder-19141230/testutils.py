from main import Adder


def test1(testCase):
  data = []
  data.append({'numbers': [2, -1, 3], 'total': 4})
  doTest(testCase, data)

def test2(testCase):
  data = []
  data.append({'numbers': [-2, 1, 3], 'total': 2})
  data.append({'numbers': [5, -10], 'total': -3})
  data.append({'numbers': [11], 'total': 8})
  data.append({'numbers': [], 'total': 8})
  doTest(testCase, data)

def test3(testCase):
  data = []
  data.append({'numbers': [], 'total': 0})
  doTest(testCase, data)


def doTest(testCase, data):
  adder = Adder()
  explanation = "adder = Adder()\n"
  for datum in data:
    for num in datum['numbers']:
      adder.add(num)
      explanation += "adder.add(" + repr(num) + ")\n"
    explanation += "adder.get_total()\n"
    expected = datum['total']
    actual = adder.get_total()
    if expected != actual:
      msg = makeMessage(explanation, expected, actual)
      testCase.fail(msg)


def makeMessage(explanation, expected, actual):
  bar = "\n\n##########EXPLANATION##########\n\n"
  msg = bar
  msg += "Sequence of calls:\n"
  msg += explanation
  msg += "\n\nExpected that final call to get_total would return: " + repr(
    expected) + "\n"
  msg += "\nActual return value was: " + repr(actual)
  msg += bar
  return msg
