## Instructions  

The file main.py contains the `Shape`, `Rectangle` and `Circle` classes shown in the lecture. Modify the `Rectangle` and `Circle` classes so that each includes a `is_inside` method that, in addition to the `self` parameter, has two parameters representing the *x* and *y* coordinates of a point, and which returns `True` if that point is inside the `Rectangle` or `Circle` and `False` otherwise.

A point that lies exactly on the border of a shape should be considered to be outside the shape.

**Maths Reminder #1:** If  the radius of a circle is *r* and its centre is at (*xc, yc*) then a point (*x,y*) is inside the circle if 

(*x-xc*)<sup>2</sup> + (*y-yc*)<sup>2</sup> < *r*<sup>2</sup>

**Maths Reminder #2:** If the top left corner of a rectangle is at point (*left,top*) and the bottom right corner is at point (*right, bottom*) then a point (*x,y*) is inside the rectangle if the following conditions are all true
* *x* > *left*
* *x* < *right*
* *y* > *bottom*
* *y* < *top*

## Examples of Use
```
> rec = Rectangle(0,0,2,4)
> inside = rec.is_inside(0,1)
> print(inside)
True
> circ = Circle(0,0,5)
> inside = circ.is_inside(3,6)
> print(inside)
False
```
## Automated Tests
There are six tests. Each test constructs a `Circle` or `Rectangle` then calls the `is_inside` method on that object with particular parameters

| Test| Constructor Call | x,y | Expected Return for `is_inside(x,y)` | 
| --- | ---  | --- | --- |
| test_1 | `Rectangle(0,0,1,2)` |  1,0 | `False` |  
| test_2 | `Rectangle(-1,-2,4,5)` |  0.99,0.49 | `True` |
| test_3 | `Rectangle(-1,-2,4,8)` |  1,2 | `False` |
| test_4 | `Circle(0,0,5)` |  3,4 | `False` |
| test_4 | `Circle(1,2,5)` |  4,5.9 | `True` |
| test_5 | `Circle(-2,-1,50)` | 37,29 | `True` |





  