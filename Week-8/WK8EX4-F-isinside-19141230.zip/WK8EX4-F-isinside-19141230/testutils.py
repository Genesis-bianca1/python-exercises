#IMPORTANT: DO NOT CHANGE THIS FILE!
from main import Circle,Rectangle

def test1(testCase):
  doRectangleInsideTest(testCase,0,0,1,2,1,0,False)

def test2(testCase):
  doRectangleInsideTest(testCase,-1,-2,4,5,0.99,0.49,True)

def test3(testCase):
  doRectangleInsideTest(testCase,-1,-2,4,8,1,2,False)

def test4(testCase):
  doCircleInsideTest(testCase,0,0,5,3,4,False)

def test5(testCase):
  doCircleInsideTest(testCase,1,2,5,4,5.9,True)

def test6(testCase):
  doCircleInsideTest(testCase,-2,-1,50,37,29,True)

  
def doRectangleInsideTest(testCase,xcen,ycen,width,height,x,y,expected):
  rec = Rectangle(xcen,ycen,width,height)
  actual = rec.is_inside(x,y)
  if actual != expected:
    msg = makeRecMessage(xcen,ycen,width,height,x,y,expected,actual)
    testCase.fail(msg)

def doCircleInsideTest(testCase,xcen,ycen,radius,x,y,expected):
  circ = Circle(xcen,ycen,radius)
  actual = circ.is_inside(x,y)
  if actual != expected:
    msg = makeCircMessage(testCase, xcen,ycen,radius,x,y,expected,actual)
    testCase.fail(msg)
    
def makeRecMessage(xcen,ycen,width,height,x,y,expected,actual):
  bar ="\n##################################\n"
  msg = bar + "Expected Result not seen\n\n"
  msg += "Created Rectangle with\n"
  msg += "xcen: " + repr(xcen) + "\n"
  msg += "ycen: " + repr(ycen) + "\n"
  msg += "width: " + repr(width) + "\n"
  msg += "height: " + repr(height) + "\n\n"
  msg += "\nCalled is_inside(" + repr(x) + "," + repr(y) + ")\n"
  msg += "expected return value: " + repr(expected) + "\n"
  msg += "actual return value: " + repr(actual) + "\n"
  return msg

def makeCircMessage(testCase,xcen,ycen,radius,x,y,expected,actual):
  bar ="\n##################################\n"
  msg = bar + "Expected Result not seen\n\n"
  msg += "Created Circle with\n"
  msg += "xcen: " + repr(xcen) + "\n"
  msg += "ycen: " + repr(ycen) + "\n"
  msg += "radius: " + repr(radius) + "\n"
  msg += "\nCalled is_inside(" + repr(x) + "," + repr(y) + ")\n"
  msg += "expected return value: " + repr(expected) + "\n"
  msg += "actual return value: " + repr(actual) + "\n"
  return msg