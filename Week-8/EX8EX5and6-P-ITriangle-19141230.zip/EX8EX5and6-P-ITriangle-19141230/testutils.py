from main import ITriangle

def test1(testCase):
  doPerimeterTest(testCase,0,0,6,4,16)

def test2(testCase):
  doPerimeterTest(testCase,1,-2,6,4,16)

def test3(testCase):
  doPerimeterTest(testCase,-2,-1,8,3,18)
  
def test4(testCase):
  doAreaTest(testCase,-2,-1,8,3,12)

def test5(testCase):
  doAreaTest(testCase,10,-9,5,7,17.5)

def test6(testCase):
  doAreaTest(testCase,11,-7,1,3,1.5)

def test7(testCase):
  doInsideTest(testCase,0,0,4,10,1,0,False)

def test8(testCase):
  doInsideTest(testCase,0,0,4,10,0.9,0,True)

def test9(testCase):
  doInsideTest(testCase,2,1,7,6,2,4,False)

def test10(testCase):
  doInsideTest(testCase,2,1,7,6,2,3.9,True)

def test11(testCase):
  doInsideTest(testCase,1,5,9,6,-2,4,False)

def test12(testCase):
  doInsideTest(testCase,1,5,9,6,-1.9,4,True)
  
def doPerimeterTest(testCase,xcen,ycen,base,height,expectedPerimeter):
  TOLERANCE = 0.01
  tri = ITriangle(xcen,ycen,base,height)
  actualPerimeter = tri.get_perimeter()
  if abs(actualPerimeter - expectedPerimeter) > TOLERANCE:
    msg = makeMessage(xcen,ycen,base,height, 'get_perimeter', expectedPerimeter, actualPerimeter)
    testCase.fail(msg)
    
def doAreaTest(testCase,xcen,ycen,base,height,expected):
  TOLERANCE = 0.01
  tri = ITriangle(xcen,ycen,base,height)
  actual = tri.get_area()
  if abs(actual - expected) > TOLERANCE:
    msg = makeMessage(xcen,ycen,base,height, 'get_area', expected, actual)
    testCase.fail(msg)

def doInsideTest(testCase, xcen,ycen,base,height,x,y,expected):
  tri = ITriangle(xcen,ycen,base,height)
  actual = tri.is_inside(x,y)
  if actual != expected:
    function_call = "is_inside(" + repr(x) + "," + repr(y) + ")"
    msg = makeMessage(xcen,ycen,base,height, function_call, expected, actual)
    testCase.fail(msg)

    
def makeMessage(xcen,ycen,base,height, function, expected, actual):
  bar ="\n##################################\n"
  msg = bar + "Expected Result not seen\n\n"
  msg += "Created ITriangle with\n"
  msg += "xcen: " + repr(xcen) + "\n"
  msg += "ycen: " + repr(ycen) + "\n"
  msg += "base: " + repr(base) + "\n"
  msg += "height: " + repr(height) + "\n\n"
  msg += "expected return from " + function + ":" + repr(expected) + "\n"
  msg += "actual return from " + function + ":" + repr(actual) + bar + "\n"
  return msg


