##
The file main.py contains the `Shape` class from the lecture.

## Exercise 5
Create a class `ITriangle` that is a subclass of `Shape`. Objects of the `ITriangle` class should represent isosceles triangles pointing upwards as illustrated in the diagram below. The centre point (xcen,ycen) should be the centre of the rectangle that bounds the triangle.

![Isosceles Triangle](./assets/Isosceles_cropped.png)

Implement an `__init__` method for the class. Then implement methods `get_area` and `get_perimeter` for the class.

The __init__ method should have the following header

```
def __init__(self,xcen,ycen,base,height):
```

**N.B.** You have to express the parameters in the order shown above, otherwise the tests will fail!




**Maths Reminders:**
If an isosceles triangle is has base *b*, height *h*, and centre point (*xc,yc*) then its:

* area  = *bh/2*

* perimeter = *b + √(b<sup>2</sup> + 4h<sup>2</sup>)*

## Exercise 6
Implement a method `is_inside` that takes the *x* and *y* co-ordinates of a point and returns `True` if the point is inside the triangle and `False` otherwise.

A simple way to determine whether a point *(x,y)* is inside the triangle is first to calculate the following two values (they measure distances from the apex of the triangle): 

*x<sup>'</sup>* = *x-xc*

*y<sup>'</sup>* = *y-yc-h/2*

**Reminder**: *xc* and *yc* are the co-ordinates of the centre of the triangle, so identical to xcen, ycen in the diagram.

The point *(x,y)* is inside the triangle if, and only if, all the following three conditions are true:

*y<sup>'</sup> + h > 0*

*2hx<sup>'</sup> - by<sup>'</sup> > 0*

*2hx<sup>'</sup> + by<sup>'</sup> < 0*

## Explanation of Automated Tests

### Tests of `get_perimeter`
| Test| Constructor Call | Expected Perimeter | 
| --- | ---  | --- | 
| test_1 | `ITriangle(0,0,6,4)` | 16 |  
| test_2 | `ITriangle(1,-2,6,4)` | 16 | 
| test_3 | `ITriangle(-2,-1,8,3)` | 18 | 

### Tests of `get_area`

| Test| Constructor Call | Expected Area | 
| --- | ---  | --- | 
| test_4 | `ITriangle(-2,-1,8,3)` | 12 |  
| test_5 | `ITriangle(10,-9,5,7)` | 17.5 | 
| test_6 | `ITriangle(11,-7,1,3)` | 1.5 | 


### Tests of `is_inside`

| Test| Constructor Call | Call to `is_inside` | Expected Return Value | 
| --- | ---  | --- | --- |
| test_7 | `ITriangle(0,0,4,10)` | `is_inside(1,0)` | `False` |
| test_8 | `ITriangle(0,0,4,10)` | `is_inside(0.9,0)` | `True` |
| test_9 | `ITriangle(2,1,7,6)` | `is_inside(2,4)` | `False` |
| test_10 | `ITriangle(2,1,7,6)` | `is_inside(2,3.9)` | `True` |
| test_11 | `ITriangle(1,5,9,6)` | `is_inside(-2,4)` | `False` |
| test_12 | `ITriangle(1,5,9,6)` | `is_inside(-1.9,4)` | `True` |