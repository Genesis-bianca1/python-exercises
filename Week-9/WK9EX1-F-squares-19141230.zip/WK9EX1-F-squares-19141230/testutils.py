import re

import numpy as np

from main import squares


def test1():
  mainfile = open('main.py')
  program_text = mainfile.read()
  mainfile.close()
  prog_split =re.split('\W+',program_text)
  forbidden = ['for', 'while']
  msg = ""
  bad_words = [word for word in prog_split if word in forbidden]
  if len(bad_words) >= 1:
    bar = '\n##################EXPLANATION###################\n'
    msg = bar + "\nThe following keywords have been used in your code: " 
    msg += word_list_string(bad_words)
    msg += "\nYou appear to be using a loop!"
    msg += bar
  return msg

def word_list_string(wordList):
  result = ""
  for word in wordList:
    result += word + ' '
  return result
  
def test2():
  expected = np.array([0,1,4,9,16,25,36,49,64,81])
  return do_test(0,10,expected)

def test3():
  expected = np.array([225, 256])
  return do_test(15,17,expected)
  
def test4():
  expected = np.array([841])
  return do_test(29,30,expected)  

def test5():
  expected = np.array([])
  return do_test(31,31,expected)

def do_test(lower,upper,expected):
  actual = squares(lower,upper)
  msg = ""
  if not np.array_equal(actual,expected):
    msg = make_message(lower,upper, actual, expected)
  return msg

def make_message(lower, upper,actual,expected):
  bar = "\n##############EXPLANATION################\n"
  msg = bar
  msg += "\nActual return value is not what was expected"
  msg += "\nFunction call: squares(" + repr(lower) +  "," + repr(upper) + ")"
  msg += "\nActual return value: " + repr(actual)
  msg += "\nExpected return value: " + repr(expected)
  msg += bar
  return msg
