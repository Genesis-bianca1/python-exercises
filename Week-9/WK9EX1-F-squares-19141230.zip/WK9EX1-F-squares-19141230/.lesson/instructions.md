## Instructions  

Write a function `squares` with the following header

```
def squares(lower,upper):
```
The function should return a Numpy array containing the squares of all the integers in the range `lower` (inclusive) to `upper` exclusive.

The function should be implemented **without** using loops, list comprehensions, or recursions (and don't worry if you don't know what list comprehensions or recursion are because you aren't allowed to use them anyway)!

## Example of Use
```
> sq = squares(1,6)
> sq
array([ 1,  4,  9, 16, 25])
```

**Hint:** The Numpy function `arange` can be used to produce an array containing a sequence of increasing values (but you can't use it to produce a squence of squares, the exercises isn't that easy!).

## Explanation of Automated Tests

**test_1:** Checks that the code does not include the words `while` or `for`.

The remaining tests call the function with different arguments and check that the result is as expected

|Test| `lower` | `upper` | Expected content of returned array |
| -- | -- | -- | -- |
| test_2 | 0 | 10 | 0,1,4,9,16,25,36,49,64,81|
| test_3 | 15 | 17 | 225, 256 |
| test_4 | 29 | 30 | 841 |
| test_5 | 31 | 31 | empty array |
  