## Instructions  

A Caesar Cypher is a simple encryption technique that works by taking a text and shifting each letter a fixed number of positions along the alphabet. For the purpose of this exercise we will assume that the case of the letter (upper or lower) is preserved. So with a shift of 2 the letter 'b' would become 'd' and 'B' would become 'D'. If the shift takes the letter beyond the end of the alphabet ('z' or 'Z') we 'wrap around'. For example, with a shift of 3 the letter 'Z' becomes 'C' and 'y' becomes 'b'. Non alphabetic characters are left unchanged.

So the phrase "Veni. Vidi. Vici!" with a shift of 5 becomes "Ajsn. Anin. Anhn!".

Write a function with the header
```
def caesar(arr,n):
```
The parameter `arr` should be a numpy array whose elements are single character strings. It should return the result of applying a Caesar cypher with shift `n`.

You should implement the function **<ins>without using loops, list comprehensions, or recursion</ins>** (and it's doesn't matter if you don't know what list comprehensions or recursion are, because you can't use them!).

## Example of Use

```
> arr = np.array(['V','e','n','i','!'])
> caesar(arr,5)
array(['A', 'j', 's', 'n', '!'], dtype=object)
```
**Hint #1:**
It might be useful to write a ufunc that applies a cypher to a single character.

**Hint #2:**
The Unicode code value of a character can be calculated using the function `ord`. If n is an integer then `chr(n)` evaluates to the character with Unicode value `n`. For example
```
> ord('a')
97
> chr(97)
'a'
```

**Hint #3:**
A character 'x' is a lower case letter if `x >= 'a' and x <='z'`. It is an upper case letter if `x >= 'A' and x <='Z'`.

## Explanation of Automated Tests

**test_1:** Checks that the code does not include the words `while` or `for`.

The remaining tests call the function with different arguments and check that the result is as expected

|Test| Contents of array passed | `shift` | Expected content of returned array |
| -- | -- | -- | -- |
| test_2 | `'V','i','d','i',' ','!'`| 5 | `'A', 'n', 'i', 'n', ' ', '!'`|
| test_3 | empty array | 12 | empty array |


