import re

import numpy as np

from main import caesar


def test1():
  mainfile = open('main.py')
  program_text = mainfile.read()
  mainfile.close()
  prog_split =re.split('\W+',program_text)
  forbidden = ['for', 'while']
  msg = ""
  bad_words = [word for word in prog_split if word in forbidden]
  if len(bad_words) >= 1:
    bar = '\n##################EXPLANATION###################\n'
    msg = bar + "\nThe following keywords have been used in your code: " 
    msg += word_list_string(bad_words)
    msg += "\nYou appear to be using a loop!"
    msg += bar
  return msg

def word_list_string(wordList):
  result = ""
  for word in wordList:
    result += word + ' '
  return result

def test2():
  original = np.array(['V','i','d','i', ' ','!'])
  expected = np.array(['A', 'n', 'i', 'n', ' ', '!'])
  return do_test(original,5,expected)

def test3():
  original = np.array([])
  expected = np.array([])
  return do_test(original,12,expected)




def do_test(original,shift,expected):
  actual = caesar(original,shift)
  msg = ""
  if not np.array_equal(actual,expected):
    msg = make_message(original,shift, actual, expected)
  return msg

def make_message(original, shift,actual,expected):
  bar = "\n##############EXPLANATION################\n"
  msg = bar
  msg += "\nActual return value is not what was expected"
  msg += "\nFunction call: caesar(" + repr(original) + "," + repr(shift) + ")"
  msg += "\nActual return value: " + repr(actual)
  msg += "\nExpected return value: " + repr(expected)
  msg += bar
  return msg

  
  