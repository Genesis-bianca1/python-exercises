import numpy as np

from main import is_magic_square


def test1():
  arr = np.array([[2,7,6],[9,5,1],[4,3,8]])
  return do_test(arr,True)

def test2():
  arr = np.array([[1,14,14,4],[11,7,6,9],[8,10,10,5],[13,2,3,15]])
  return do_test(arr,True)

def test3():
  arr = np.array([[2,7,6],[9,5,1],[4,3,8],[5,1,2]])
  return do_test(arr,False)

def test4():
  arr = np.array([[2,8,6],[9,5,1],[4,3,8]])
  return do_test(arr,False)

def do_test(arr,expected):
  msg = ""
  actual = is_magic_square(arr)
  if actual != expected:
    msg = make_message(arr,actual,expected)
  return msg

def make_message(arr,actual,expected):
  bar = "\n#######EXPLANATION#########\n"
  msg = bar
  msg += "\nActual and expected return values not the same"
  msg += "\nArray passed:\n"
  msg += repr(arr)
  msg += "\nActual return value: " + repr(actual)
  msg += "\nExpected return value: " + repr(expected)
  msg += bar
  return msg
