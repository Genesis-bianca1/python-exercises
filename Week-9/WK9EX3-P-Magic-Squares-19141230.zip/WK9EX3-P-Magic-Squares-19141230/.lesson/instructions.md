## Instructions  

A *Magic Square* is a square of numbers whose rows, columns, and diagonals all add up to the same value. For example, in the square below, all the rows, columns, and both diagonals, add up to 15.

```
2 7 6
9 5 1
4 3 8
```

The above square could be represented as 2-D Numpy Array created by the expression below
```
np.array([[2,7,6],[9,5,1],[4,3,8]])
```

Write a function with the following header

```
def is_magic_square(arr):
```

The function should return `True` if the array `arr` represents a magic square, and `False` otherwise.

Try to avoid using Python loops where Numpy allows you to avoid them (you probably will end up writing at least one loop however). Make use of the hints shown below.


**Hint #1:** The sum of a Numpy array can be calculated using the `sum` method, as illustrated below.

```
> a = np.array([4,2,6])
> a.sum()
12
```

**Hint #2:** If `arr` is an 2-d array with as many columns as rows then
* `arr[...,n]` is a 1-D array containing the elements in row `n`
* `arr[n,...]` is a 1-D array containing the elements in column `n`
* `arr.diagonal()` is a 1-D array containing the elements along the diagonal running from top left to bottom right
* `arr[..., ::-1].diagonal()` is a 1-D array containing the elements along the diagonal running from top right to bottom left
 
**Example:**
```
> arr = np.array([[2,7,6],[9,5,1],[4,3,8]])
> arr[...,1]
array([7, 5, 3])
> arr[0,...]
array([2, 7, 6])
> arr.diagonal()
array([2, 5, 8])
> arr[..., ::-1].diagonal()
array([6, 5, 4])
```

**Note #1:** For the purpose of this exercise, magic squares in which the same number appears more than once are still considered to be magic.

**Note #2:** An array can't represent a magic square if doesn't represent a square at all. The array must represent a table with the same number of rows as it has columns.

## Explanation of Automated Tests
-----
**test_1**

Function call: 

`is_magic_square(np.array([[2,7,6],[9,5,1],[4,3,8]]))`

Expected Return Value: `True`

-----
**test_2**

Function call:

`is_magic_square(np.array([[1,14,14,4],[11,7,6,9],[8,10,10,5],[13,2,3,15]]))`

Expected Return Value: `True`

-----
**test_3**

Function call:

`is_magic_square(np.array([[2,7,6],[9,5,1],[4,3,8],[5,1,2]]))`

Expected Return Value: `False`

Note that the array passed has 4 rows, but only 3 columns

-----
**test_4**

Function call:

`is_magic_square(np.array([[2,8,6],[9,5,1],[4,3,8]])`

Expected Return Value: `False`
