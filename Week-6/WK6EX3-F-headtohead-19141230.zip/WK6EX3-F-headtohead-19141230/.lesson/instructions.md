# Instructions  

There are two features that limit the reusability of the 'Condorcet' code developed in the lecture. The first is that the filename is 'hardcoded' into the program, and the second is that the list of candidates is also hardcoded. In this exercise we will begin to address the first of those problems.

Created a modified `head_to_head` function where, rather than hardcoding the name of the file, we pass it as a third parameter to the function. So the header of the function should now look like this.

```
def head_to_head(canda, candb, filename):
```
You should now be able to calculate the results of head to head contests using data from any file, not just the 'votes.txt' file used in the previous examples. This Replit project contains two text files:  'votes.txt' is the 'Tennessee Capital' example used in the lectures, and 'votes.txt' contains has the same format as 'votes.txt'  but contains results of an election where the candidates are 'Arthur', 'Clare', and 'Betty'. You should be able to run your modified head_to_head using either file. Here is an illustration of what you should see if type expressions intp the Replit console.


```
> ab = head_to_head('Arthur','Betty','votes2.txt')
> print(ab)
-10
> ac = head_to_head('Arthur','Clare','votes2.txt')
> print(ac)
-4
> bc = head_to_head('Betty','Clare','votes2.txt')
> print(bc)
30
> kn = head_to_head('Knoxville','Nashville','votes.txt')
> print(kn)
-36
``` 

Note that the first three calls above use the file 'votes2.txt',but the last one uses 'votes.txt' (it is there to demonstrate that the function still works when the original file is used).


To save time, the solution used in the lectures has been renamed as `lecture_head_to_head` and included in the main.py file.

## Explanation of Automated Tests

The function calls, and expected return values for the automated tests are as follows

| Test| Function call | Expected Return Value |
| --- | ---  | --- |
| test_1 | `head_to_head('Arthur','Betty','votes2.txt')`| -10 |
| test_2 | `head_to_head('Arthur','Clare','votes2.txt')`| -4 |
| test_3 | `head_to_head('Betty','Clare','votes2.txt')`| 30|
| test_4 | `head_to_head('Clare','Betty','votes2.txt')`| -30 |
| test_5 | `head_to_head('Knoxville','Nashville','votes.txt')`| -36 |
| test_6 | `head_to_head('Nashville','Memphis','votes.txt')`| 16 |


  