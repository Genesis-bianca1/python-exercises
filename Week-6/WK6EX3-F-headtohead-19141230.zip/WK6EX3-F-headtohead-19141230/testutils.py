from main import head_to_head

def test1(testcase):
  doTest(testcase,'Arthur','Betty','votes2.txt',-10)
def test2(testcase):
  doTest(testcase,'Arthur','Clare','votes2.txt',-4)
def test3(testcase):
  doTest(testcase,'Betty','Clare','votes2.txt',30)
def test4(testcase):
  doTest(testcase,'Clare','Betty','votes2.txt',-30)
def test5(testcase):
  doTest(testcase,'Knoxville','Nashville','votes.txt',-36)
def test6(testcase):
  doTest(testcase,'Nashville','Memphis','votes.txt',16)


def doTest(testcase,candA,candB,filename,expectScore):
  score = head_to_head(candA,candB,filename)
  if score != expectScore:
    msg = makeMessage(candA,candB,filename,expectScore,score)
    testcase.fail(msg)

def makeMessage(candA,candB,filename,expectScore,actualScore):
  bar ="\n##########EXPLANATION#############\n"
  msg = bar + "Function call: " + callToStr("head_to_head",candA,candB,filename)
  msg += "\nExpected return value: " + repr(expectScore)
  msg += "\nActual return value:" + repr(actualScore)
  msg += "\nExpected and actual values are unequal" + bar
  return msg

def callToStr(functor,*args):
  call = functor + "("
  nbrArgs = len(args)
  for i in range(0,nbrArgs):
    call += repr(args[i])
    if i == nbrArgs-1:
      call += ")"
    else:
      call += ","
  return call