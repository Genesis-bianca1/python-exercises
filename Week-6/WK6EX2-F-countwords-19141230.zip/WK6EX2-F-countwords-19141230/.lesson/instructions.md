# Instructions  

Write a function with the following first line

```
def countWords(filename):
```
The parameter is the name of a file. The function should return the number of "words" in that file, where a word is any string that does not contain white space (in other words, if `str` is a string, then `str.split()` will split into its component words).

## Example of Use
If the file `example.txt` contained the following text
```
this is 
just an
example
```
then  ` countWords('example.txt')` would return 5.

N.B. If you want to call your `countWords` function from the Replit console, you need to first press the Replit "Run" button. If you want to see some output as well when you press the "Run" button, you could add the following program to your 'main.py' file.

```
if __name__ == "__main__":
  print("countWords('example.txt') returns ", countWords('example.txt'))
```

## Explanation of Automated Tests
There is one test. It performs the following operations **10** times over
* Delete any file with the name `_infile.txt`
* Generate a new file called `_infile.txt` containing a random number of randomly created words
* Call `countWords('_infile.txt')` and check that the return value is as expected.