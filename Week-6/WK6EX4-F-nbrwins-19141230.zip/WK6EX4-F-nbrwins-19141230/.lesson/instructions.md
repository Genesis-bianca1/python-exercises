## Instructions

Copy the `head_to_head` code from the previous exercise, and use it to create a modified `nbr_wins` function that also takes a filename as a parameter. It should pass the value of this parameter to the `head_to_head` function. The first line of `nbr_wins`  should now look like this:

```
def nbr_wins(candidate, opponents, filename):
```
and the call to head_to_head that occurs in that function should look like this
```
if head_to_head(candidate,oppo, filename) > 0:
```
You should now be able to run your `nbr_wins` function with any file in the correct format (including, but not limited to, the two files included in this project). Here is what a call would look like in the Replit console
```
> a = nbr_wins('Arthur',['Arthur','Betty','Clare'],'votes2.txt')
print(a)
0
```
To save you time, the version of the `nbr_wins` function used in the lecture has been renamed `lecture_nbr_wins` and included in the main.py file

## Explanation of Automated Tests

The function calls, and expected return values for the automated tests are as follows

| Test| Function call | Expected Return Value |
| --- | ---  | --- |
| test_1 | `nbr_wins('Arthur',['Arthur','Betty','Clare'],'votes2.txt')`| 0 |
| test_2 | `nbr_wins('Betty',['Arthur','Betty','Clare'],'votes2.txt')`| 2|
| test_3 | `nbr_wins('Nashville',['Chattanooga','Knoxville','Memphis','Nashville'],'votes.txt')`| 3 |
