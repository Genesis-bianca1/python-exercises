import os
import io
import sys
from contextlib import redirect_stdout

def test1(testcase):
  #delete any existing example2.txt
  filename = "example2.txt"
  if os.path.exists(filename):
    os.remove(filename)
  outputStr = runMain("")
  if outputStr != "":
    msg = makeMessage("Output to console was generated")
    testcase.fail(msg)
  inFile = open('example.txt')
  inWords = inFile.read().split()
  inFile.close()
  outFile = open('example2.txt')
  outWords = outFile.read().split()
  if outWords != inWords:
    msg = makeMessage("File was incorrectly copied. Look at the input and output files")
    testcase.fail(msg)
    testcase.fail()

def runMain(inputStr):
  output = io.StringIO()
  sys.stdin=io.StringIO(inputStr)
  mainfile = open('main.py')
  with redirect_stdout(output):
	  exec(mainfile.read(),{ "__name__":"__main__"})
  mainfile.close()
  return output.getvalue()

def makeMessage(explanation):
  bar ="\n##########EXPLANATION#############\n"
  msg = bar + explanation + bar
  return msg