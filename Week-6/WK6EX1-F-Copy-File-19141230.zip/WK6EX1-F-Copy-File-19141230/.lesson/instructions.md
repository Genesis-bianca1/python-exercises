# Instructions  

There is a file called example.txt associated with this exercise. Write a program that reads in the contents of this file, and then copies it to a file example2.txt. The program should **not** print any output to the console.

**N.B.** The automated test will delete any existing example2.txt file.

**Hint:**

The way to do this is to
* Open the file example.txt for reading
* Read the contents of example.txt into a variable
* Open the file example2.txt for writing
* Write the text read from example.txt into example2.txt
* Close both files 

##  Explanation of automated tests.
There is one automated test. It deletes any existing example2.txt file. Runs your program and then checks that the output file is identical to the input file. 

If there are extra line breaks or spaces in the output file, the test will still pass, but you should try to ensure that the two files are identical.