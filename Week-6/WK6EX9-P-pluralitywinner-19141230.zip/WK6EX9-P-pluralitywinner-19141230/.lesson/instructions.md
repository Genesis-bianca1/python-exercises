## Instructions

If we score an election using _plurality voting_ (&quot;First past the post&quot;) we only look at voters&#39; first preferences. The winner of an election is the candidate with the most first preferences.

Write a function with the following first line
```
def count_votes(filename,candidate):
```
which returns the number of **first preference** votes for the specified candidate in the specified file. For example, using the `votes2.txt` file that you can find in the Replit project we could use this function in the Python console as follows:
```
> bvotes = count_votes('votes2.txt','Betty')
> print(bvotes)
20
```
Now use this function to create a second function with the following first line
```
def plurality_winner(filename, candidates):
```
The parameter `filename` is the name of a file, and `candidates` is a list of the candidates in that file. The function should return a list with two elements. The first element should be the name of the plurality winner, and the second should be the number of votes that winner received.

## Example of Use
Using the `votes.txt` file in the Replit project for this exercise we could make a function call in the Python console as follows:
```
>candidates = ['Memphis','Nashville','Chattanooga','Knoxville']
>win = plurality_winner('votes.txt',candidates)
>print(win)
['Memphis', 42]
```
N.B. The files `votes.txt` and `votes2.txt` are included in the Replit project for this exercise. Don't change them because they are used by the automated tests.

## Explanation of Automated Tests 

The function calls made by the automated tests, and the expected return values are as follows:

| Test| Function call | Expected return value |
| --- | ---  | --- |
| test_1 | `plurality_winner('votes.txt',['Memphis','Nashville','Chattanooga','Knoxville'])`| `['Memphis', 42]` |
| test_2 | `plurality_winner(''votes2.txt',['Arthur','Betty','Clare'])`| `['Arthur', 45]` |
