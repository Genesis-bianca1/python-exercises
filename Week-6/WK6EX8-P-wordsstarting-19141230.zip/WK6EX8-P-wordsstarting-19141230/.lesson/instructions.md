## Instructions
Write a function with the following first line
```
def words_starting(file,lower,upper):
```
The parameters are, respectively the name of a text file and two single letter strings. The function should return a list containing the words in the file whose first letter lies between `lower` to `upper` inclusive (and case sensitive). The words should be listed in the order in which they occur. If the same word occurs more than once in the file,and its first letter is in the specified range, then it should appear more than once in the returned list.

When comparing letters you should use unicode ordering, so that all capital letters come before all lower case letters. If either of the parameters `lower` or `upper` has more than one character then just ignore all characters after the first. If a word contains an apostrophe, treat the apostrophe as part of the word.

As an example, suppose the file `richmond.txt` contained the lines

>England hath long been mad and scarred herself  
>the brother blindly shed the brother's blood  
>the father rashly slaughtered his own son  
>the son compelled been butcher to the sire  
>all this divided York and Lancaster  
>divided in their dire division  
>now let Richmond and Elizabeth  
>the true succeeders of each royal house  
>by God's fair ordinance conjoin together  
>and let their heirs God if thy will be so  
>enrich the time to come with smooth-faced peace  
>with smiling plenty and fair prosperous days  

<br>

If `richmond.txt` is in the same folder as the Python file containing your code then the effect of calling the function in a Python console would be as illustrated below.

```
> caps = words_starting('richmond.txt','A','Z')
> print(caps)
['England', 'York', 'Lancaster', 'Richmond', 'Elizabeth', 'God’s', 'God']
```
**Hint #1:** You can compare strings using the same relational operators as you would use for numbers. For example `'a' < 'b'` evaluates to`True`. The comparison uses Unicode ordering so `'a' < 'B'` would evaluate to `False`. 

**Hint #2:** The individual letters of a string can be obtained using notation similar to that used to obtain elements of a list. If `mystring` is a string then `mystring[0]` is the first letter in that string, `mystring[1]` is the second, and so on.

Example:
```
> mystring = 'Hello'
> print(mystring[0])
H
> print(mystring[1])
e
```

**N.B.** The file `richmond.txt` is included in the Replit project for this exercise. Don't change it because it is used by the automated tests.

## Explanation of Automated Tests 

The function calls made by the automated tests, and the expected return values are as follows:

| Test| Function call | Expected return value |
| --- | ---  | --- |
| test_1 | `words_starting('richmond.txt','A','Z')`| `['England', 'York', 'Lancaster', 'Richmond', 'Elizabeth', 'God’s', 'God']` |
| test_2 | `words_starting('richmond.txt','d','d')`| `['divided', 'divided', 'dire', 'division', 'days']` |
| test_3 | `words_starting('richmond.txt','m','n')`| `['mad', 'now']` |
| test_4 | `words_starting('richmond.txt','n','m')`| `[]` |
