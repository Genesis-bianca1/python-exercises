## Instructions

Write a function with the following first lime

```
def get_candidates(filename):
```
Whose parameter is a file name and which reads the **first** line in that file, in order to extract the list of candidates. (In this exercise, and those that follow, you may assume that every line contains all of the candidates).

## Examples of Use
```
> get_candidates('votes.txt')
['Memphis', 'Nashville', 'Chattanooga', 'Knoxville']
> get_candidates('votes2.txt')
['Arthur', 'Betty', 'Clare']
```


**Hint #1:** 
The list slicing technique explained in the lecture slides will probably come in handy.

**Hint #2:** Your `get_candidates`  function will need to open the file. Make sure that it also closes this file before returning.

## Explanation of Automated Tests

There are two automated tests. Each makes a call to `get_candidates` and checks that the list returned contains the required strings. It does **not** check the order in which those strings appear. For example the first test would pass if the function returned `['Arthur','Betty','Clare']` or `['Betty','Arthur','Clare']` or any other permutation of the three strings in those lists.


| Test| Function call | Expect that returned list will contain (in any order) |
| --- | ---  | --- |
| test_1 | `get_candidates('votes2.txt')`| `'Arthur'`  `'Betty'` `'Clare'` |
| test_2 | `get_candidates('votes.txt')`| `'Chattanooga'` `'Knoxville'` `'Memphis'` `'Nashville'`  |
