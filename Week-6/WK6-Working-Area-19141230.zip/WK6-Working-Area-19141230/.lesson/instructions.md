## Instructions  
This project has been created so that you can experiment with code related to this week's exercises.