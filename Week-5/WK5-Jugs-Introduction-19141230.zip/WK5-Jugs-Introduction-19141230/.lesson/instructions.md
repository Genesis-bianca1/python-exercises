## Introduction to Water Jugs Mini-Project
The next few exercises form a mini-project based around the "Die Hard Water Jugs" example used in previous weeks.  

As a reminder, the problem, in its most general form, is that you are given a pair of jugs of capacity A litres and B litres. You then have to make up C litres, where C != A and C != B. A,B, and C are integers. The desired volume could be in either of the jugs, or it could be present as the combined volume of the jugs. 

The following algorithm will work, so long as the capacities of the jugs are integers and relatively prime, that is to say that they do not have any common factors . 

```
While the desired amount has not been achieved:
If jug A is empty, fill it
Else if jug B is full, empty it
Else transfer as much water as possible from jug A to jug B
```

This week, we will develop a program that solves the problem for any relatively prime pair of capacities  `A` and `B` and for any desired volume `C` such that `0 <= C  <= A + B`

As is often the case with software projects, some decisions have already been made regarding the way in which the program is to  be developed, and you will need to respect these decisions as you build up the program in the next few exercises. These decisions are:

* The state of the jugs will be represented by a list containing two integers whose values are the volumes of water in jugs A and B in that order, For example `[5,6]` represents a state where there are 5 litres in jug A and 6 litres in jug B.

* The operations that can be performed on the jugs will be represented by two-letter strings, as follows:


| String | Meaning|
| --- | ---  | 
| `FA` | Fill jug A from tap
| `EB` | Empty jug B
| `AB` | Transfer as much water as possible from jug A to jug B


* The code written will include (at least) two functions named `do_next_op`, and `main`.

* The function `do_next_op`  must not generate any output.

* The code will be developed **without** using the keywords `break`, `continue` or `pass`. (The reasons for avoiding those keywords have been explained in the lectures.)


