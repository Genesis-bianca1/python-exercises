## Instructions
In this exercise you must write a function with the following first line

```
def do_next_op(state,capA,capB):
```

The parameters are the state of the jugs, represented as a two element list, as explained in the introduction, and the capacities of jugs A and B. The function should return the two letter code for the next operation to be performed, as explained in the introduction. It should also adjust the state to reflect the effect of performing that operation.

**Note:** Make sure that you understand how functions handle list-valued parameters. We talked about this in the week 4 lecture session, so you may wish to look back at the lecture slides, and try some examples in Python Tutor.


## Example of use (in Python console)
```
> state = [0,4]
> op = do_next_op(state,3,4)
> print(op)
FA
> print(state)
[3, 4]
```
## Explanation of automated tests

The initial state, capacities of the jugs, and expected final state for the tests are set out below.

| Test| Initial state | capA | capB| Expected return value | Expected final state |
| --- | ---  | --- | --- | --- | --- |
| test_1 | `[1,2]` | `3` | `4` | `AB` | `[0,3]` |
| test_2 | `[2,3]` | `4` | `3` | `EB` | `[2,0]` |
| test_3 | `[0,3]` | `7` | `5` | `FA` | `[7,3]` |